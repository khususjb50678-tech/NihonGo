// 🇯🇵 NIHON QUIZ — SETTINGS
module.exports = {
  BOT_TOKEN: "YOUR_BOT_TOKEN_HERE",
  OWNER_ID: 8500012067,
  ADMIN_IDS: [],
  AUTO_BACKUP_HOURS: 2,
  DATA_CHANNEL_CHAT_ID: "@dataquiznihongo",
  DATA_CHANNEL_URL: "https://t.me/dataquiznihongo"
};
