# NihonGo 🇯🇵

Telegram bot untuk belajar bahasa Jepang.

## Struktur

- `src/` — source code bot
- `data/` — data pembelajaran
- `assets/` — aset gambar
- `config/settings.example.js` — contoh konfigurasi
- `config/settings.js` — konfigurasi lokal/server (jangan di-upload)
- `package.json` — dependency dan script

## Menjalankan di server

```bash
npm install
cp config/settings.example.js config/settings.js
# isi BOT_TOKEN dan konfigurasi lain di config/settings.js
npm start
```

## Keamanan

Jangan commit:
- Bot token
- database user
- file `.env`
- `config/settings.js`

Project ini disusun agar source code dapat dikelola melalui GitHub, sementara rahasia tetap berada di server.
