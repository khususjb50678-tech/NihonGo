const { Telegraf, Markup, Input } = require('telegraf');
const fs = require('fs');
const path = require('path');
const os = require('os');
const zlib = require('zlib');
const { BOT_TOKEN, OWNER_ID, ADMIN_IDS = [], AUTO_BACKUP_HOURS = 2, DATA_CHANNEL_CHAT_ID = '', DATA_CHANNEL_URL = '' } = require('./settings');
const studyData = require('./study-data.json');
const STUDY_DATA = { verbs: studyData.verbs || [], nouns: studyData.nouns || [], na_adjectives: studyData.na_adjectives || [], i_adjectives: studyData.i_adjectives || [] };

// Build kana-only conjugation forms for verbs so the study list/test is not kanji-heavy.
function kanaVerbForms(v){
  const k=String(v.kana||'');
  if(!k) return {masu:v.masu||'',te:v.te||'',dictionary:v.dictionary||k,nai:v.nai||'',ta:v.ta||''};
  if(v.type==='suru'){
    const stem=k.slice(0,-2);
    return {masu:stem+'します',te:stem+'して',dictionary:k,nai:stem+'しない',ta:stem+'した'};
  }
  if(v.type==='kuru') return {masu:'きます',te:'きて',dictionary:k,nai:'こない',ta:'きた'};
  if(v.type==='ichidan'){
    const stem=k.endsWith('る')?k.slice(0,-1):k;
    return {masu:stem+'ます',te:stem+'て',dictionary:k,nai:stem+'ない',ta:stem+'た'};
  }
  if(v.type==='godan'){
    const last=k.slice(-1), stem=k.slice(0,-1);
    const iMap={う:'い',く:'き',ぐ:'ぎ',す:'し',つ:'ち',ぬ:'に',ぶ:'び',む:'み',る:'り'};
    const aMap={う:'わ',く:'か',ぐ:'が',す:'さ',つ:'た',ぬ:'な',ぶ:'ば',む:'ま',る:'ら'};
    let te,ta;
    if(k==='いく' || k==='行く') { te=stem+'って'; ta=stem+'った'; }
    else if(['う','つ','る'].includes(last)) { te=stem+'って'; ta=stem+'った'; }
    else if(['む','ぶ','ぬ'].includes(last)) { te=stem+'んで'; ta=stem+'んだ'; }
    else if(last==='く') { te=stem+'いて'; ta=stem+'いた'; }
    else if(last==='ぐ') { te=stem+'いで'; ta=stem+'いだ'; }
    else if(last==='す') { te=stem+'して'; ta=stem+'した'; }
    else { te=v.te||''; ta=v.ta||''; }
    const masu=stem+(iMap[last]||'')+'ます';
    const nai=(last==='ある' ? 'ない' : stem+(aMap[last]||'')+'ない');
    return {masu,te,dictionary:k,nai,ta};
  }
  return {masu:v.masu||'',te:v.te||'',dictionary:k,nai:v.nai||'',ta:v.ta||''};
}
for(const v of STUDY_DATA.verbs){
  const f=kanaVerbForms(v);
  Object.assign(v,{masuKana:f.masu,teKana:f.te,dictionaryKana:f.dictionary,naiKana:f.nai,taKana:f.ta});
}


if (!BOT_TOKEN || BOT_TOKEN === 'PASTE_BOT_TOKEN_HERE') throw new Error('Isi BOT_TOKEN di settings.js.');
if (!OWNER_ID) throw new Error('Isi OWNER_ID di settings.js.');

const bot = new Telegraf(BOT_TOKEN);
const DB_FILE = path.join(__dirname, 'database.json');
const sessions = new Map();
const states = new Map();

// Tampilan teks global: pesan bot dibuat sebagai Telegram Quote.
// Markdown lama dikonversi sederhana ke HTML agar bold tetap berfungsi.
function beautifyBotText(text, extra = {}) {
  if (typeof text !== 'string') return { text, extra };
  const ex = { ...(extra || {}) };
  const mode = ex.parse_mode || ex.parseMode || '';
  if (mode === 'HTML' && /<blockquote[ >]/i.test(text)) return { text, extra: ex };
  if (mode === 'HTML') return { text: `<blockquote>${text}</blockquote>`, extra: ex };

  // Convert legacy Markdown to safe HTML.
  let out = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const codes = [];
  out = out.replace(/`([^`\n]+)`/g, (_, x) => {
    const i = codes.push(`<code>${x}</code>`) - 1;
    return `@@CODE${i}@@`;
  });
  out = out.replace(/\*([^*\n]+)\*/g, '<b>$1</b>');
  out = out.replace(/_([^_\n]+)_/g, '<i>$1</i>');
  out = out.replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2">$1</a>');
  out = out.replace(/@@CODE(\d+)@@/g, (_, i) => codes[Number(i)] || '');
  ex.parse_mode = 'HTML';
  delete ex.parseMode;
  return { text: `<blockquote>${out}</blockquote>`, extra: ex };
}

// Terapkan format Quote ke reply teks dan caption media secara global.
bot.use(async (ctx, next) => {
  const originalReply = ctx.reply.bind(ctx);
  ctx.reply = (text, extra = {}) => {
    const f = beautifyBotText(text, extra);
    return originalReply(f.text, f.extra);
  };
  const originalReplyWithPhoto = ctx.replyWithPhoto?.bind(ctx);
  if (originalReplyWithPhoto) {
    ctx.replyWithPhoto = (photo, extra = {}) => {
      if (extra && typeof extra.caption === 'string') {
        const f = beautifyBotText(extra.caption, extra);
        extra = { ...f.extra, caption: f.text };
      }
      return originalReplyWithPhoto(photo, extra);
    };
  }
  return next();
});

async function sendDataChannel(ctx, report){
  if(!DATA_CHANNEL_CHAT_ID) return;
  try{
    await bot.telegram.sendMessage(DATA_CHANNEL_CHAT_ID, report, {disable_web_page_preview:true});
  }catch(e){
    console.warn('Gagal mengirim data ke channel:', e.message);
  }
}
function userLabel(ctx, name=''){
  const username=ctx.from.username ? '@'+ctx.from.username : '(tanpa username)';
  return `Nama: ${name || '(belum ada)'}\nUsername: ${username}\nTelegram ID: ${ctx.from.id}`;
}

// Complete JLPT Kanji N5-N1 loader. Data is cached locally after first launch.
const KANJI_LEVELS=['N5','N4','N3','N2','N1'];
const KANJI_URLS={N5:'https://raw.githubusercontent.com/evanclan/OpenJLPT/main/data/json/kanji/n5.json',N4:'https://raw.githubusercontent.com/evanclan/OpenJLPT/main/data/json/kanji/n4.json',N3:'https://raw.githubusercontent.com/evanclan/OpenJLPT/main/data/json/kanji/n3.json',N2:'https://raw.githubusercontent.com/evanclan/OpenJLPT/main/data/json/kanji/n2.json',N1:'https://raw.githubusercontent.com/evanclan/OpenJLPT/main/data/json/kanji/n1.json'};
const kanjiCacheFile=path.join(__dirname,'kanji-data.json');
let kanjiLevels={N5:[],N4:[],N3:[],N2:[],N1:[]};
const KANJI_ID_SOURCE='https://www.kanji-pad.app/id/kanji';
let kanjiIdMeaningMap={};
function decodeKanjiHtml(s){return String(s).replace(/<[^>]+>/g,' ').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>').replace(/&quot;/gi,'\"').replace(/&#39;/gi,"'").replace(/\s+/g,' ').trim();}
function parseIndonesianKanjiPage(html){
  const map={};
  const re=/<a[^>]+href=[\"'](?:https?:\/\/www\.kanji-pad\.app)?\/id\/kanji\/[^\"']+[\"'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while((m=re.exec(html))){
    const text=decodeKanjiHtml(m[1]);
    const chars=Array.from(text);
    if(chars.length<2) continue;
    const ch=chars[0];
    if(!/[\u3400-\u9fff]/.test(ch)) continue;
    const meaning=chars.slice(1).join('').trim();
    if(meaning) map[ch]=meaning;
  }
  return map;
}
function normalizeKanjiEntry(x,l){
  const meaning=kanjiIdMeaningMap[x.character] || 'arti belum tersedia';
  const readings=[...(x.onyomi||[]),...(x.kunyomi||[])].filter(Boolean).join(' / ');
  return [x.character,readings,meaning,x.strokes,l];
}
function loadKanjiCache(){try{if(!fs.existsSync(kanjiCacheFile))return;const d=JSON.parse(fs.readFileSync(kanjiCacheFile,'utf8'));for(const l of KANJI_LEVELS)if(Array.isArray(d[l]))kanjiLevels[l]=d[l]}catch{}}
function saveKanjiCache(){fs.writeFileSync(kanjiCacheFile,JSON.stringify(kanjiLevels,null,2))}
loadKanjiCache();
async function fetchKanjiLevels(){
  const r={N5:[],N4:[],N3:[],N2:[],N1:[]};
  try{
    const html=await fetchUrl(KANJI_ID_SOURCE);
    kanjiIdMeaningMap=parseIndonesianKanjiPage(html);
    console.log('Arti kanji Bahasa Indonesia dimuat:',Object.keys(kanjiIdMeaningMap).length);
  }catch(e){console.warn('Sumber arti kanji Indonesia gagal dimuat:',e.message);}
  await Promise.all(KANJI_LEVELS.map(async l=>{
    try{
      const t=await fetchUrl(KANJI_URLS[l]);
      const a=JSON.parse(t);
      if(Array.isArray(a))r[l]=a.map(x=>normalizeKanjiEntry(x,l));
    }catch(e){console.warn('Kanji '+l+' gagal dimuat:',e.message)}
  }));
  let changed=false;
  for(const l of KANJI_LEVELS)if(r[l].length){kanjiLevels[l]=r[l];changed=true}
  if(changed)saveKanjiCache();
  return changed;
}

// Vocabulary cache for Minna no Nihongo Lessons 1–50.
// The bundled PDF is kept under assets/ as the user's supplied source.
// If a chapter has not been cached yet, the bot can fetch the corresponding
// lesson table from the public vocabulary reference and cache the result locally.
const vocabCacheFile = path.join(__dirname, 'vocab-data.json');
let vocabChapters = {};
if (fs.existsSync(vocabCacheFile)) {
  try { vocabChapters = JSON.parse(fs.readFileSync(vocabCacheFile, 'utf8')); } catch { vocabChapters = {}; }
}
for (let i=1;i<=50;i++) if (!Array.isArray(vocabChapters[i])) vocabChapters[i]=[];
function saveVocabCache(){fs.writeFileSync(vocabCacheFile,JSON.stringify(vocabChapters,null,2));}
function decodeHtml(s){
  return String(s)
    .replace(/<br\s*\/?\s*>/gi,' ')
    .replace(/<[^>]+>/g,' ')
    .replace(/&nbsp;/gi,' ')
    .replace(/&amp;/gi,'&').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>')
    .replace(/&quot;/gi,'"').replace(/&#39;/gi,"'")
    .replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi,(_,n)=>String.fromCharCode(parseInt(n,16)))
    .replace(/\s+/g,' ').trim();
}
function hasJapanese(s){ return /[\u3040-\u30ff\u3400-\u9fff]/.test(String(s)); }
function parseIndonesianVocabHtml(html){
  const rows=[]; const trRe=/<tr[^>]*>([\s\S]*?)<\/tr>/gi; let m;
  while((m=trRe.exec(html))){
    const cells=[]; const tdRe=/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi; let c;
    while((c=tdRe.exec(m[1]))) cells.push(decodeHtml(c[1]));
    if(cells.length < 3) continue;
    const jp=cells[0], kanji=cells[1], meaning=cells.slice(2).join(' ').trim();
    if(!hasJapanese(jp) || !meaning || /^(bentuk|kata|contoh|sopan|biasa|positif|negatif|arti|keterangan|kelompok)/i.test(jp)) continue;
    // Keep the Indonesian meaning from the source. Remove obvious table noise.
    const clean=meaning.replace(/\s+/g,' ').trim();
    if(clean && !/^(bentuk|kata kerja|kata benda|kata sifat)$/i.test(clean)) rows.push([jp,kanji==='-'?'':kanji,clean]);
  }
  const seen=new Set();
  return rows.filter(r=>{const k=r.join('|');if(seen.has(k))return false;seen.add(k);return true;});
}
async function fetchUrl(url){
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),15000);
  try{
    const r=await fetch(url,{signal:controller.signal,headers:{'user-agent':'NihonQuizBot/6.0'} });
    if(!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.text();
  } finally { clearTimeout(timer); }
}
async function fetchVocabChapter(chapter){
  // Indonesian-first source. The fallback keeps the bot usable if the first
  // source is temporarily unavailable, but we do not expose its English
  // meanings: only Indonesian data are accepted into the cache.
  const book=chapter<=25?1:2;
  const candidates=[
    `https://cilacapklik.com/2023/11/belajar-bahasa-jepang-minna-no-nihongo-${book}-bab-${chapter}.html`,
    `https://cilacapklik.com/2024/08/belajar-bahasa-jepang-minna-no-nihongo-${book}-bab-${chapter}.html`
  ];
  let lastErr=null;
  for(const url of candidates){
    try{
      const html=await fetchUrl(url); const rows=parseIndonesianVocabHtml(html);
      if(rows.length>=5){ vocabChapters[chapter]=rows; saveVocabCache(); return rows; }
    }catch(e){ lastErr=e; }
  }
  throw lastErr || new Error('Kosakata Bahasa Indonesia tidak ditemukan');
}
async function getVocabChapter(chapter){
  if(!Number.isInteger(chapter)||chapter<1||chapter>50) return [];
  if(vocabChapters[chapter]?.length) return vocabChapters[chapter];
  return fetchVocabChapter(chapter);
}
async function loadVocabChapters(chapters){
  const out=[];
  for(let i=0;i<chapters.length;i+=5){
    const batch=chapters.slice(i,i+5);
    const results=await Promise.all(batch.map(c=>getVocabChapter(c).catch(()=>[])));
    results.forEach((rows,i)=>out.push({chapter:batch[i],rows}));
  }
  return out;
}


const HIRAGANA=[
['あ','a'],['い','i'],['う','u'],['え','e'],['お','o'],['か','ka'],['き','ki'],['く','ku'],['け','ke'],['こ','ko'],['さ','sa'],['し','shi'],['す','su'],['せ','se'],['そ','so'],['た','ta'],['ち','chi'],['つ','tsu'],['て','te'],['と','to'],['な','na'],['に','ni'],['ぬ','nu'],['ね','ne'],['の','no'],['は','ha'],['ひ','hi'],['ふ','fu'],['へ','he'],['ほ','ho'],['ま','ma'],['み','mi'],['む','mu'],['め','me'],['も','mo'],['や','ya'],['ゆ','yu'],['よ','yo'],['ら','ra'],['り','ri'],['る','ru'],['れ','re'],['ろ','ro'],['わ','wa'],['を','wo'],['ん','n'],
['が','ga'],['ぎ','gi'],['ぐ','gu'],['げ','ge'],['ご','go'],['ざ','za'],['じ','ji'],['ず','zu'],['ぜ','ze'],['ぞ','zo'],['だ','da'],['ぢ','ji'],['づ','zu'],['で','de'],['ど','do'],['ば','ba'],['び','bi'],['ぶ','bu'],['べ','be'],['ぼ','bo'],['ぱ','pa'],['ぴ','pi'],['ぷ','pu'],['ぺ','pe'],['ぽ','po']
];
const KATAKANA=[
['ア','a'],['イ','i'],['ウ','u'],['エ','e'],['オ','o'],['カ','ka'],['キ','ki'],['ク','ku'],['ケ','ke'],['コ','ko'],['サ','sa'],['シ','shi'],['ス','su'],['セ','se'],['ソ','so'],['タ','ta'],['チ','chi'],['ツ','tsu'],['テ','te'],['ト','to'],['ナ','na'],['ニ','ni'],['ヌ','nu'],['ネ','ne'],['ノ','no'],['ハ','ha'],['ヒ','hi'],['フ','fu'],['ヘ','he'],['ホ','ho'],['マ','ma'],['ミ','mi'],['ム','mu'],['メ','me'],['モ','mo'],['ヤ','ya'],['ユ','yu'],['ヨ','yo'],['ラ','ra'],['リ','ri'],['ル','ru'],['レ','re'],['ロ','ro'],['ワ','wa'],['ヲ','wo'],['ン','n'],
['ガ','ga'],['ギ','gi'],['グ','gu'],['ゲ','ge'],['ゴ','go'],['ザ','za'],['ジ','ji'],['ズ','zu'],['ゼ','ze'],['ゾ','zo'],['ダ','da'],['ヂ','ji'],['ヅ','zu'],['デ','de'],['ド','do'],['バ','ba'],['ビ','bi'],['ブ','bu'],['ベ','be'],['ボ','bo'],['パ','pa'],['ピ','pi'],['プ','pu'],['ペ','pe'],['ポ','po']
];
function kanaMenu(kind,page=0){
 const data=kind==='hiragana'?HIRAGANA:KATAKANA, per=30, total=Math.max(1,Math.ceil(data.length/per)), start=page*per, part=data.slice(start,start+per);
 const title=kind==='hiragana'?'HIRAGANA':'KATAKANA';
 const rows=[[Markup.button.callback('📝 TEST '+title,'kana_test:'+kind)],[Markup.button.callback('⚙️ ATUR TEST','user_material_settings')],[Markup.button.callback('🔤 🇯🇵 ひらがな • 🇮🇩 HIRAGANA','kana:hiragana'),Markup.button.callback('🔤 🇯🇵 カタカナ • 🇮🇩 KATAKANA','kana:katakana')]];
 rows.push([Markup.button.callback('⬅️','kna_page:'+kind+':'+Math.max(0,page-1)),Markup.button.callback(`${page+1}/${total}`,'noop'),Markup.button.callback('➡️','kna_page:'+kind+':'+Math.min(total-1,page+1))]);
 rows.push([Markup.button.callback('🏠 MENU UTAMA','menu')]);
 return Markup.inlineKeyboard(rows);
}
function showKana(kind,page=0){
 const data=kind==='hiragana'?HIRAGANA:KATAKANA, per=30, start=page*per, part=data.slice(start,start+per), title=kind==='hiragana'?'HIRAGANA':'KATAKANA';
 return `🔤 <b>${title}</b>\n\n🇮🇩 <b>Total:</b> ${data.length} huruf\n📖 <b>Halaman:</b> ${Math.floor(start/per)+1}/${Math.max(1,Math.ceil(data.length/per))}\n\n${part.map((x,i)=>`<blockquote>🇯🇵 <b>${start+i+1}. ${escapeHtml(x[0])}</b>\n🇮🇩 <b>Bacaan:</b> ${escapeHtml(x[1])}</blockquote>`).join('\n')}`;
}

const initial = {
 questions: [
  {id:1,type:'choice',question:'「おはようございます」の意味は？',options:['Selamat malam','Selamat pagi','Selamat siang','Selamat tinggal'],answer:'B',explanation:'Artinya selamat pagi.'},
  {id:2,type:'choice',question:'「ありがとう」の意味は？',options:['Maaf','Permisi','Terima kasih','Tolong'],answer:'C',explanation:'Artinya terima kasih.'},
  {id:3,type:'choice',question:'「水」は何ですか？',options:['Api','Air','Tanah','Kayu'],answer:'B',explanation:'水（みず） berarti air.'},
  {id:4,type:'fill',question:'Lengkapi: 「日本」 dibaca ______.',answerText:'にほん',explanation:'日本 dibaca にほん (nihon).'}
 ],
 users: [], admins: [], answerHistory: [],
 settings: { quizMode:'immediate' }
};

function loadDB(){
 if(!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE,JSON.stringify(initial,null,2));
 try { return JSON.parse(fs.readFileSync(DB_FILE,'utf8')); }
 catch { fs.writeFileSync(DB_FILE,JSON.stringify(initial,null,2)); return JSON.parse(JSON.stringify(initial)); }
}
let db=loadDB();
db.questions??=[]; db.users??=[]; db.admins??=[]; db.answerHistory??=[];
db.kanjiAdditional??=[];
db.settings??={quizMode:'immediate'};
db.settings.quizMode??='immediate';
db.settings.testSettings??={};
const QUIZ_COUNT=20;
const DEFAULT_TEST_COUNT=10;
for(let i=1;i<=QUIZ_COUNT;i++){
  db.settings.testSettings['quiz_'+i]??={count:DEFAULT_TEST_COUNT,timerMode:'none',time:0};
}
for(const key of ['kanji_N5','kanji_N4','kanji_N3','kanji_N2','kanji_N1','kanji_additional','kana_hiragana','kana_katakana','verbs','nouns','na','i','vocab']){
  db.settings.testSettings[key]??={count:DEFAULT_TEST_COUNT,timerMode:'none',time:0};
}
// Existing questions without a quiz stay in Quiz 1; existing Quiz 2/3 are preserved.
db.questions.forEach(q=>{if(!Number.isInteger(Number(q.quiz))||Number(q.quiz)<1||Number(q.quiz)>QUIZ_COUNT)q.quiz=1;});
saveDB();
function saveDB(){fs.writeFileSync(DB_FILE,JSON.stringify(db,null,2));}
function isOwner(id){return Number(id)===Number(OWNER_ID);}
function isAdmin(id){return isOwner(id)||ADMIN_IDS.map(Number).includes(Number(id))||db.admins.map(Number).includes(Number(id));}
function ensureUser(ctx){
 let u=db.users.find(x=>x.user_id===ctx.from.id);
 if(!u){u={user_id:ctx.from.id,username:ctx.from.username||'',name:'',games:0,total_questions:0,correct:0,points:0,testSettings:{},activity:[],startedAt:new Date().toISOString()};db.users.push(u);}
 u.testSettings??={};
 u.activity??=[];
 u.startedAt??=new Date().toISOString();
 u.username=ctx.from.username||u.username||''; saveDB(); return u;
}
function markActivity(ctx,key,label){
 const u=ensureUser(ctx),now=new Date().toISOString();
 u.activity??=[];
 let a=u.activity.find(x=>x.key===key);
 if(!a){a={key,label,starts:0,firstStartedAt:now,lastStartedAt:now};u.activity.push(a);}
 a.label=label;a.starts=(a.starts||0)+1;a.lastStartedAt=now;
 u.lastActivityAt=now; saveDB(); return u;
}
function materialKeyFromSession(s){
 if(!s)return null;
 if(s.type==='quiz')return 'quiz_'+(s.quizNo||1);
 if(s.type==='kanji')return 'kanji_'+s.kind;
 if(s.type==='kana')return 'kana_'+s.kind;
 if(s.type==='study')return s.kind;
 if(s.type==='vocab')return 'vocab';
 return null;
}
function materialLabelFromKey(k){return testKeyLabel(k);}
function recordAnswer(ctx,s,qdata){
 const u=ensureUser(ctx),key=materialKeyFromSession(s),label=materialLabelFromKey(key||'');
 const entry={user_id:ctx.from.id,name:s.name||u.name||'',username:ctx.from.username||u.username||'',question_id:qdata.question_id??null,question:qdata.question||'',type:qdata.type||'study',correct:!!qdata.correct,user_answer:qdata.user_answer??'',correct_answer:qdata.correct_answer??'',materialKey:key,materialLabel:label,at:new Date().toISOString()};
 db.answerHistory.push(entry);
 if(db.answerHistory.length>50000)db.answerHistory=db.answerHistory.slice(-50000);
 saveDB();
}
function mainMenu(id){
 // Label tombol dibuat singkat supaya TIDAK terpotong di layar HP.
 // Bahasa Jepang hanya ditampilkan di konten materi; tombol memakai nama Indonesia yang jelas.
 const rows=[
  [Markup.button.callback('📝 MULAI QUIZ','quiz_start')],
  [Markup.button.url('📊 HASIL DATA', DATA_CHANNEL_URL || 'https://t.me/dataquiznihongo')],
  [Markup.button.callback('🈶 KANJI','kanji_menu')],
  [Markup.button.callback('🔤 HIRAGANA','kana:hiragana'),Markup.button.callback('🔤 KATAKANA','kana:katakana')],
  [Markup.button.callback('🟣 KATA KERJA','study:verbs'),Markup.button.callback('🟤 KATA BENDA','study:nouns')],
  [Markup.button.callback('🟢 SIFAT な','study:na'),Markup.button.callback('🔵 SIFAT い','study:i')],
  [Markup.button.callback('📚 KOSAKATA','vocab')],
  [Markup.button.callback('📊 SKOR SAYA','my_score'),Markup.button.callback('🏆 SKOR TERTINGGI','top_score')]
 ];
 if(isAdmin(id)) rows.push([Markup.button.callback('⚙️ ADMIN PANEL','admin_panel')]);
 rows.push([Markup.button.callback('👨‍💻 DEVELOPER','developer')]);
 return Markup.inlineKeyboard(rows);
}
function back(){return Markup.inlineKeyboard([[Markup.button.callback('🏠 MENU UTAMA','menu')]]);}
function adminMenu(){return Markup.inlineKeyboard([
 [Markup.button.callback('📝 KELOLA SOAL','admin_questions')],
 [Markup.button.callback('🈶 KELOLA KANJI','kanji_admin')],
 [Markup.button.callback('⚙️ PENGATURAN QUIZ','quiz_settings'),Markup.button.callback('🔢 JUMLAH SOAL','quiz_count')],
 [Markup.button.callback('⏱️ WAKTU TEST','timer_settings'),Markup.button.callback('📢 BROADCAST','broadcast')],
 [Markup.button.callback('📈 STATISTIK','admin_stats')],
 [Markup.button.callback('👥 KELOLA ADMIN','admin_manage')],
 [Markup.button.callback('🗑️ RESET DATA / STATISTIK','admin_reset')],
 [Markup.button.callback('📖 CARA PENGGUNAAN','admin_help')],
 [Markup.button.callback('🏆 🇮🇩 SKOR TERTINGGI','top_score')],
 [Markup.button.callback('🏠 MENU USER','menu')]
]);}
function quizManageKeyboard(action){
 const rows=[];
 for(let i=1;i<=QUIZ_COUNT;i+=2){
  const row=[Markup.button.callback('📝 QUIZ '+i,action+':'+i)];
  if(i+1<=QUIZ_COUNT) row.push(Markup.button.callback('📝 QUIZ '+(i+1),action+':'+(i+1)));
  rows.push(row);
 }
 rows.push([Markup.button.callback('🔙 KELOLA SOAL','admin_questions')]);
 return Markup.inlineKeyboard(rows);
}
function questionMenu(){return Markup.inlineKeyboard([
 [Markup.button.callback('➕ TAMBAH SOAL CEPAT','admin_add'),Markup.button.callback('➕ SOAL + MEDIA','admin_add_media')],[Markup.button.callback('✏️ EDIT SOAL','admin_edit'),Markup.button.callback('🖼️🎧 EDIT MEDIA','admin_edit_media')],
 [Markup.button.callback('🗑️ HAPUS SOAL','admin_delete'),Markup.button.callback('📋 SEMUA SOAL','admin_list')],
 [Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]
]);}
function answerKeyboard(q){
 return Markup.inlineKeyboard(q.options.map((x,i)=>[Markup.button.callback(`${String.fromCharCode(65+i)}. ${x}`,`ans:${String.fromCharCode(65+i)}:${q.id}`)]));
}

function optionLabel(q, value){
  if(q?.type==='fill') return String(value||'(kosong)');
  const key=String(value||'').trim().toUpperCase();
  const m=/^[A-F]$/.test(key)?key.match(/^([A-F])$/):null;
  if(m){
    const i=key.charCodeAt(0)-65;
    const label=q?.options?.[i];
    if(label!==undefined) return `${key}. ${label}`;
  }
  return String(value||'(kosong)');
}
function buttonLabel(ctx, callback, fallback){
  const rows=ctx.callbackQuery?.message?.reply_markup?.inline_keyboard||[];
  return rows.flat().find(b=>b.callback===callback)?.text || fallback;
}
function cleanReportText(v,max=220){
  const t=String(v??'').replace(/\s+/g,' ').trim();
  return t.length>max?t.slice(0,max-1)+'…':t;
}
function prettyReport(title, user, metaLines, mistakes=[]){
  const lines=[
    '╭━━━━━━━━━━━━━━━━━━━━╮',
    `┃ 📊 ${title}`,
    '╰━━━━━━━━━━━━━━━━━━━━╯',
    '',
    '╭─ 👤 IDENTITAS',
    ...String(user||'').split('\n').map(x=>`│ ${x}`),
    '╰────────────────────',
    '',
    '╭─ 🏆 HASIL AKHIR',
    ...metaLines.map(x=>`│ ${x}`),
    '╰────────────────────'
  ];
  if(mistakes.length){
    lines.push('',`╭─ ❌ DETAIL KESALAHAN (${mistakes.length})`);
    mistakes.slice(0,15).forEach((m,i)=>{
      lines.push(`│`, `│ ${i+1}. ${cleanReportText(m.question||m.word||m.kanji||m.kana||'-',180)}`);
      if(m.userAnswer!==undefined) lines.push(`│ 👤 Jawaban kamu : ${cleanReportText(m.userAnswer,180)}`);
      if(m.correctAnswer!==undefined) lines.push(`│ ✅ Jawaban benar: ${cleanReportText(m.correctAnswer,180)}`);
    });
    if(mistakes.length>15) lines.push(`│`, `│ … dan ${mistakes.length-15} kesalahan lainnya.`);
    lines.push('╰────────────────────');
  } else {
    lines.push('', '╭─ ✅ HASIL SEMPURNA', '│ Tidak ada jawaban yang salah. Mantap! 🎉', '╰────────────────────');
  }
  return lines.join('\n');
}
function shuffle(a){return [...a].sort(()=>Math.random()-.5);}
function modeLabel(){return db.settings.quizMode==='immediate'?'⚡ LANGSUNG':'📝 SELESAIKAN DULU';}
function testSetting(key){
 const x=db.settings.testSettings?.[key]||{};
 const count=Number(x.count); const time=Number(x.time);
 return {count:Number.isFinite(count)&&count>=1?Math.min(100,Math.floor(count)):DEFAULT_TEST_COUNT,timerMode:['none','per_question','per_quiz'].includes(x.timerMode)?x.timerMode:'none',time:Number.isFinite(time)&&time>=1?Math.min(3600,Math.floor(time)):0};
}
function questionsPerQuiz(quizNo=1){return testSetting('quiz_'+Number(quizNo)).count;}
const MATERIAL_KEYS=['kanji_N5','kanji_N4','kanji_N3','kanji_N2','kanji_N1','kanji_additional','kana_hiragana','kana_katakana','verbs','nouns','na','i','vocab'];
function normalizeTestSetting(x){
 const count=Number(x?.count), time=Number(x?.time);
 return {count:Number.isFinite(count)&&count>=1?Math.min(100,Math.floor(count)):DEFAULT_TEST_COUNT,timerMode:['none','per_question','per_quiz'].includes(x?.timerMode)?x.timerMode:'none',time:Number.isFinite(time)&&time>=1?Math.min(3600,Math.floor(time)):0};
}
function userTestSetting(ctx,key){
 const u=ensureUser(ctx); u.testSettings??={}; u.testSettings[key]??={count:DEFAULT_TEST_COUNT,timerMode:'none',time:0};
 const cfg=normalizeTestSetting(u.testSettings[key]); u.testSettings[key]=cfg; saveDB(); return cfg;
}
function timerSetting(key){return testSetting(key);}
function formatSeconds(sec){sec=Math.max(0,Math.floor(sec));return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`;}
function clearSessionTimer(s){if(s?.timerInterval){clearInterval(s.timerInterval);s.timerInterval=null;}if(s?.timerTimeout){clearTimeout(s.timerTimeout);s.timerTimeout=null;}}
async function startSessionTimer(ctx,s,label,seconds,onTimeout){
 clearSessionTimer(s); if(!seconds)return;
 s.timerSeconds=seconds; s.timerEndsAt=Date.now()+seconds*1000;
 const tick=async()=>{
  if(!sessions.has(ctx.from.id)||s!==sessions.get(ctx.from.id)){clearSessionTimer(s);return;}
  const left=Math.max(0,Math.ceil((s.timerEndsAt-Date.now())/1000));
  if(s.questionMessageId){
   try{
    const base=s.questionBaseText||'';
    const text=base.replace(/\n\n⏱️ Sisa waktu: \d{2}:\d{2}$/,'')+`\n\n⏱️ Sisa waktu: ${formatSeconds(left)}`;
    await ctx.telegram.editMessageText(ctx.chat.id,s.questionMessageId,undefined,text,{parse_mode:s.questionParseMode||undefined,...(s.questionKeyboard||{})});
   }catch(e){}
  }
  if(left<=0){clearSessionTimer(s);await onTimeout();}
 };
 await tick();
 s.timerInterval=setInterval(tick,1000);
 s.timerTimeout=setTimeout(async()=>{clearSessionTimer(s);if(sessions.has(ctx.from.id)&&s===sessions.get(ctx.from.id))await onTimeout();},seconds*1000+150);
}
async function prepareSessionTimer(ctx,s,key,onTimeout){
 const cfg=timerSetting(key); s.timerKey=key; s.timerMode=cfg.timerMode; s.timerSeconds=cfg.time;
 if(cfg.timerMode==='per_quiz' && !s.timerStarted) {s.timerStarted=true; await startSessionTimer(ctx,s,'quiz',cfg.time,onTimeout);}
 else if(cfg.timerMode==='per_question') await startSessionTimer(ctx,s,'question',cfg.time,onTimeout);
}


async function requireTestName(ctx,pending){
 const u=ensureUser(ctx);
 if(u.name && String(u.name).trim().length>=2) return false;
 states.set(ctx.from.id,{type:'start_name'});
 await ctx.reply('🇯🇵 *お名前を入力してください。*\n🇮🇩 *Silakan masukkan nama kamu.*\n\n✨ *Nama akan disimpan untuk statistik dan seluruh hasil test.*',{parse_mode:'Markdown'});
 return true;
}
async function launchKanaTest(ctx,kind){const data=kind==='hiragana'?HIRAGANA:KATAKANA;const cfg=userTestSetting(ctx,'kana_'+kind);const selected=shuffle(data).slice(0,Math.min(cfg.count,data.length));sessions.set(ctx.from.id,{type:'kana',kind,items:selected,index:0,correct:0,mistakes:[],startedAt:new Date().toISOString(),timerMode:cfg.timerMode,timerTime:cfg.time,timerStarted:false,name:ensureUser(ctx).name});markActivity(ctx,'kana_'+kind,kind==='hiragana'?'Hiragana':'Katakana');await editScreen(ctx,`📝 *TEST ${kind==='hiragana'?'HIRAGANA':'KATAKANA'}*\n\nJumlah soal: *${selected.length}*\nSoal akan diacak.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🚀 MULAI TEST','kanastart')],[Markup.button.callback('⚙️ ATUR TEST','user_material_settings')],[Markup.button.callback('🔙 KEMBALI',`kana:${kind}`)]])});}
async function launchKanjiTest(ctx,kind){let data;if(kind==='additional')data=(db.kanjiAdditional||[]).map(x=>({character:x.character,reading:x.reading,meaning:x.meaning}));else{await ensureKanji();data=kanjiLevels[kind].map(x=>({character:x[0],reading:x[1],meaning:x[2]}));}if(!data.length)return ctx.reply('⚠️ Data Kanji belum tersedia.',back());const cfg=userTestSetting(ctx,'kanji_'+kind);const selected=shuffle(data).slice(0,Math.min(cfg.count,data.length));sessions.set(ctx.from.id,{type:'kanji',kind,items:selected,index:0,correct:0,mistakes:[],startedAt:new Date().toISOString(),timerMode:cfg.timerMode,timerTime:cfg.time,timerStarted:false,name:ensureUser(ctx).name});markActivity(ctx,'kanji_'+kind,kind==='additional'?'Kanji Lainnya':'Kanji '+kind);return showKanjiQuestion(ctx);}
async function launchStudyTest(ctx,kind){const data=STUDY_META[kind].data,cfg=userTestSetting(ctx,kind),selected=shuffle(data).slice(0,Math.min(cfg.count,data.length));sessions.set(ctx.from.id,{type:'study',kind,items:selected,index:0,correct:0,mistakes:[],startedAt:new Date().toISOString(),timerMode:cfg.timerMode,timerTime:cfg.time,timerStarted:false,name:ensureUser(ctx).name});markActivity(ctx,kind,testKeyLabel(kind));await editScreen(ctx,studyTestText(ctx,kind),{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🚀 MULAI TEST','studystart')],[Markup.button.callback('⚙️ ATUR TEST','user_material_settings')],[Markup.button.callback('🔙 KEMBALI','study:'+kind)],[Markup.button.callback('🏠 MENU UTAMA','menu')]])});}
async function beginQuiz(ctx,name,quizNo=1){
 const pool=db.questions.filter(q=>Number(q.quiz)===Number(quizNo));
 const ids=shuffle(pool.map(q=>q.id)).slice(0,Math.min(questionsPerQuiz(quizNo),pool.length));
 const cfg=testSetting('quiz_'+Number(quizNo));
 sessions.set(ctx.from.id,{type:'quiz',ids,index:0,correct:0,points:0,currentId:null,name,quizNo:Number(quizNo),answered:false,mistakes:[],startedAt:new Date().toISOString(),timerMode:cfg.timerMode,timerTime:cfg.time,timerStarted:false});
 const u=ensureUser(ctx); markActivity(ctx,'quiz_'+Number(quizNo),'Quiz '+Number(quizNo));u.name=name;saveDB();
 await ctx.reply(`✨ *SELAMAT DATANG, ${name.toUpperCase()}!*\n\n🇯🇵 *QUIZ ${quizNo}* siap dimulai.\n\n📝 ${ids.length} soal\n⚙️ Mode: *${modeLabel()}*\n⭐ 10 poin untuk jawaban benar`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🚀 MULAI MENGERJAKAN','quiz_next')],[Markup.button.callback('❌ BATAL','menu')]])});
}
async function sendQuestionMedia(ctx,q){
 if(q.photo){try{await ctx.replyWithPhoto(q.photo,{caption:'🖼️ Soal visual'});}catch(e){console.warn('Foto soal gagal:',e.message)}}
 if(q.audio){try{await ctx.replyWithAudio(q.audio,{caption:'🎧 Dengarkan audio'});}catch(e){console.warn('Audio soal gagal:',e.message)}}
}
async function editActiveQuestion(ctx,s,text,extra={}){
 const msg=ctx.callbackQuery?.message;
 if(msg?.message_id) s.questionMessageId=msg.message_id;
 let finalText=text;
 if(s.timerMode && s.timerMode!=='none' && s.timerEndsAt){
  finalText += `\n\n⏱️ Sisa waktu: ${formatSeconds(Math.max(0,Math.ceil((s.timerEndsAt-Date.now())/1000)))}`;
 }
 const f=beautifyBotText(finalText,extra);
 s.questionBaseText=f.text;
 s.questionParseMode=f.extra.parse_mode;
 s.questionKeyboard=f.extra.reply_markup?{reply_markup:f.extra.reply_markup}:{};
 try{
  if(s.questionMessageId) return await ctx.telegram.editMessageText(ctx.chat.id,s.questionMessageId,undefined,f.text,f.extra);
 }catch(e){}
 const sent=await ctx.reply(f.text,f.extra); s.questionMessageId=sent.message_id; return sent;
}

async function showQuestion(ctx){
 const s=sessions.get(ctx.from.id); if(!s)return ctx.reply('Sesi quiz tidak ditemukan.',back());
 if(s.index>=s.ids.length){clearSessionTimer(s);return finishQuiz(ctx);}
 const q=db.questions.find(x=>x.id===s.ids[s.index]); if(!q){s.index++;return showQuestion(ctx);}
 s.currentId=q.id;s.answered=false;s.lastAnswer='';
 const header=`🇯🇵 *NIHON QUIZ*

👤 *${s.name}*
📝 Soal *${s.index+1}/${s.ids.length}*
⭐ Skor: *${s.points}*`;
 await sendQuestionMedia(ctx,q);
 if(q.type==='fill') await editActiveQuestion(ctx,s,`${header}

*${q.question}*

Ketik jawabanmu di chat.`,{parse_mode:'Markdown'});
 else await editActiveQuestion(ctx,s,`${header}

*${q.question}*

Pilih jawabanmu:`,{parse_mode:'Markdown',...answerKeyboard(q)});
 const timeout=async()=>{const current=sessions.get(ctx.from.id);if(!current||current!==s||s.answered)return;s.lastAnswer='(waktu habis)';await handleAnswer(ctx,q,false,true);};
 if(s.timerMode==='per_question') await startSessionTimer(ctx,s,'question',s.timerTime,timeout);
 else if(s.timerMode==='per_quiz' && !s.timerStarted){s.timerStarted=true;await startSessionTimer(ctx,s,'quiz',s.timerTime,async()=>{if(s.answered)return; s.lastAnswer='(waktu habis)'; await handleAnswer(ctx,q,false,true); if(sessions.has(ctx.from.id)) await finishQuiz(ctx);});}
}
async function finishQuiz(ctx){
 const s=sessions.get(ctx.from.id); if(!s)return; clearSessionTimer(s);
 const total=s.ids.length,accuracy=total?Math.round(s.correct/total*100):0,u=ensureUser(ctx);
 u.games++;u.total_questions+=total;u.correct+=s.correct;u.points+=s.points;u.name=s.name;saveDB();
 const mistakes=s.mistakes||[];
 const report=prettyReport('HASIL DATA — NIHONGO QUIZ',userLabel(ctx,s.name),[
  `📚 Jenis         : Quiz ${s.quizNo||1}`,
  `📝 Jumlah soal   : ${total}`,
  `✅ Benar         : ${s.correct}`,
  `❌ Salah         : ${total-s.correct}`,
  `🎯 Akurasi       : ${accuracy}%`,
  `⭐ Poin          : ${s.points}`,
  `🕒 Selesai       : ${new Date().toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})}`
 ],mistakes);
 await sendDataChannel(ctx,report);
 sessions.delete(ctx.from.id);
 await ctx.reply(`<blockquote>🎊 <b>QUIZ SELESAI, ${escapeHtml(s.name.toUpperCase())}!</b>

📝 <b>Soal:</b> ${total}
🇮🇩 <b>Benar:</b> ${s.correct}
🇮🇩 <b>Salah:</b> ${total-s.correct}
⭐ <b>Skor:</b> ${s.points}
🎯 <b>Akurasi:</b> ${accuracy}%

🌸 <b>Kerja bagus! Sampai jumpa di test berikutnya.</b></blockquote>`,{parse_mode:'HTML',...Markup.inlineKeyboard([[Markup.button.callback('🔄 QUIZ LAGI','quiz_start'),Markup.button.callback('🏆 TOP SKOR','top_score')],[Markup.button.callback('🏠 MENU UTAMA','menu')]])});
}

async function handleAnswer(ctx,q,isCorrect,timedOut=false){
 const s=sessions.get(ctx.from.id); if(!s||s.answered)return;
 if(s.timerMode==='per_question'||timedOut) clearSessionTimer(s);
 s.answered=true;if(isCorrect){s.correct++;s.points+=10;}
 const u=ensureUser(ctx);
 recordAnswer(ctx,s,{question_id:q.id,question:q.question,type:q.type,correct:isCorrect,user_answer:q.type==='fill'?(s.lastAnswer||''):(optionLabel(q,s.lastAnswer)),correct_answer:q.type==='fill'?q.answerText:optionLabel(q,q.answer)});
 if(!isCorrect) s.mistakes.push({question:q.question,userAnswer:q.type==='fill'?(s.lastAnswer||'(kosong)'):optionLabel(q,s.lastAnswer),correctAnswer:q.type==='fill'?q.answerText:optionLabel(q,q.answer)});
 const next=Markup.inlineKeyboard([[Markup.button.callback('➡️ SOAL BERIKUTNYA','quiz_next')]]);
 if(db.settings.quizMode==='immediate'){
  const msg=timedOut?'⏱️ *WAKTU HABIS!*':(isCorrect?'✅ *BENAR!* +10 poin 🎉':'❌ *SALAH!*');
  let reveal='';
  if(q.type==='fill') reveal=`\n\n💡 Jawaban benar: *${q.answerText}*`;
  else reveal=`\n\n💡 Jawaban benar: *${optionLabel(q,q.answer)}*`;
  if(q.explanation) reveal+=`\n📖 ${q.explanation}`;
  await ctx.reply(`${msg}${reveal}\n\n⭐ Skor: *${s.points}*`,{parse_mode:'Markdown',...next});
 } else {
  await ctx.reply(isCorrect?'Jawaban dicatat.':'Jawaban dicatat.',next);
 }
}

async function editScreen(ctx, text, extra = {}) {
  const msg = ctx.callbackQuery?.message;
  const f = beautifyBotText(text, extra);
  // A photo message cannot be converted to a text message.
  if (msg?.photo) return ctx.reply(f.text, f.extra);
  try { return await ctx.editMessageText(f.text, f.extra); }
  catch (e) {
    const desc=e?.response?.description||e?.message||String(e);
    if(/message is not modified/i.test(desc)) return msg;
    console.error('editScreen gagal:',desc);
    return ctx.reply(f.text, f.extra);
  }
}

function greetingJapanese(){const hour=Number(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Jakarta',hour:'numeric',hour12:false}).format(new Date()));if(hour>=4&&hour<11)return ['おはようございます！','Selamat pagi!'];if(hour>=11&&hour<18)return ['こんにちは！','Selamat siang!'];return ['こんばんは！','Selamat malam!'];}
bot.start(async ctx=>{
 const u=ensureUser(ctx);
 const [jp,id]=greetingJapanese();
 const banner=path.join(__dirname,'assets','start-banner.png');
 const hasName=u.name&&String(u.name).trim().length>=2;
 if(!hasName){
   states.delete(ctx.from.id);
   states.set(ctx.from.id,{type:'start_name'});
   const caption=`<blockquote><b>🇯🇵 NIHON QUIZ</b> 🌸

🇯🇵 <b>${jp}</b>
🇮🇩 <b>${id}</b>

🇯🇵 <b>お名前を入力してください。</b> 📝
🇮🇩 <b>Silakan masukkan nama kamu terlebih dahulu.</b>

✨ <b>Nama ini akan tersimpan dan otomatis dipakai untuk statistik serta semua hasil test.</b>

✍️ <b>Ketik nama kamu di chat:</b></blockquote>`;
   if(fs.existsSync(banner)) return ctx.replyWithPhoto({source:banner},{caption,parse_mode:'HTML'});
   return ctx.reply(caption,{parse_mode:'HTML'});
 }
 states.delete(ctx.from.id);
 const caption=`<blockquote><b>🇯🇵 NIHON QUIZ</b>

🇯🇵 <b>${jp}</b>
🇮🇩 <b>${id}</b>

🇯🇵 <b>日本語の勉強へようこそ！</b> 📚
🇮🇩 <b>Selamat datang di pembelajaran Bahasa Jepang!</b>

💪 🇯🇵 <b>今日も少しずつ頑張りましょう！</b>
🇮🇩 <b>Hari ini belajar sedikit demi sedikit juga tidak apa-apa. Yang penting terus maju!</b> 🌸</blockquote>`;
 if(fs.existsSync(banner)) return ctx.replyWithPhoto({source:banner},{caption,parse_mode:'HTML',...mainMenu(ctx.from.id)});
 return ctx.reply(caption,{parse_mode:'HTML',...mainMenu(ctx.from.id)});
});
bot.command('admin',async ctx=>{if(!isAdmin(ctx.from.id))return ctx.reply('⛔ Akses ditolak.');await ctx.reply('👑 *ADMIN PANEL*\n\nOwner dan Admin memiliki hak pengelolaan yang sama.',{parse_mode:'Markdown',...adminMenu()});});
bot.command('backup',async ctx=>{if(!isOwner(ctx.from.id))return ctx.reply('⛔ Command ini khusus OWNER.');await sendBackup(ctx.from.id,'manual');});
bot.action('noop',async ctx=>{await ctx.answerCbQuery();});
bot.action('menu',async ctx=>{await ctx.answerCbQuery();await editScreen(ctx, '<blockquote><b>🇯🇵 NIHON QUIZ</b> 📚\n\n🇮🇩 <b>MENU PEMBELAJARAN</b>\n\n✨ <b>Pilih materi yang ingin kamu pelajari hari ini!</b></blockquote>',{parse_mode:'HTML',...mainMenu(ctx.from.id)});});
bot.action('quiz_start',async ctx=>{
 await ctx.answerCbQuery();
 const rows=[];for(let i=1;i<=QUIZ_COUNT;i+=2){const a=countsForQuiz(i),row=[Markup.button.callback(`📝 QUIZ ${i} (${a})`,`qpick:${i}`)];if(i+1<=QUIZ_COUNT){const b=countsForQuiz(i+1);row.push(Markup.button.callback(`📝 QUIZ ${i+1} (${b})`,`qpick:${i+1}`));}rows.push(row);}
 const any=Array.from({length:QUIZ_COUNT},(_,i)=>countsForQuiz(i+1)).some(Boolean);if(!any)return ctx.reply('📭 Belum ada soal quiz.',back());
 rows.push([Markup.button.callback('🏠 MENU UTAMA','menu')]);
 await editScreen(ctx,`<blockquote>📝 <b>MULAI QUIZ</b>\n\n🇯🇵 <b>クイズを選んでください。</b>\n🇮🇩 <b>Pilih quiz yang ingin kamu kerjakan.</b>\n\n🇮🇩 <b>Jumlah soal mengikuti pengaturan masing-masing Quiz.</b> ✨</blockquote>`,{parse_mode:'HTML',...Markup.inlineKeyboard(rows)});
});
function countsForQuiz(n){return db.questions.filter(q=>Number(q.quiz)===Number(n)).length;}
bot.action(/^qpick:(\d{1,2})$/,async ctx=>{await ctx.answerCbQuery();const quizNo=Number(ctx.match[1]);if(quizNo<1||quizNo>QUIZ_COUNT)return;const count=countsForQuiz(quizNo);if(!count)return ctx.reply(`📭 Quiz ${quizNo} belum memiliki soal.`,back());const u=ensureUser(ctx);if(u.name&&String(u.name).trim().length>=2)return beginQuiz(ctx,u.name,quizNo);states.set(ctx.from.id,{type:'quiz_name',quizNo});await ctx.reply(`📝 *QUIZ ${quizNo}*\n\n> 🇯🇵 *クイズの準備ができました！*\n> 🇮🇩 *Quiz siap dikerjakan!* ✨\n\n> 👤 *Nama:* ${u.name}`,{parse_mode:'Markdown'});});
bot.action('quiz_next',async ctx=>{await ctx.answerCbQuery();const s=sessions.get(ctx.from.id);if(s&&s.answered){s.index++;s.answered=false;}return showQuestion(ctx);});
bot.action(/^ans:([A-F]):(\d+)$/,async ctx=>{await ctx.answerCbQuery();const letter=ctx.match[1],id=Number(ctx.match[2]),q=db.questions.find(x=>x.id===id);if(!q)return;const s=sessions.get(ctx.from.id);if(!s||s.currentId!==id||s.answered)return;s.lastAnswer=letter;await handleAnswer(ctx,q,q.answer===letter);});

bot.on('photo',async ctx=>{
 const st=states.get(ctx.from.id);if(!st||!isAdmin(ctx.from.id))return;
 if(st.type==='replace_photo'){const q=db.questions.find(x=>x.id===st.id);if(!q)return;q.photo=ctx.message.photo[ctx.message.photo.length-1].file_id;saveDB();states.delete(ctx.from.id);return ctx.reply('✅ Foto soal diperbarui.',questionMenu());}
 if(st.type==='batch_media'&&st.queue[st.index]?.kind==='photo'){const q=db.questions.find(x=>x.id===st.queue[st.index].id);if(!q)return; q.photo=ctx.message.photo[ctx.message.photo.length-1].file_id;saveDB();advanceBatchMedia(ctx);return continueBatchMedia(ctx);}
 if(st.type==='broadcast_photo'){return broadcastPreview(ctx,{type:'photo',file_id:ctx.message.photo[ctx.message.photo.length-1].file_id,caption:ctx.message.caption||''});}
 if(st.type==='add_media_photo'||st.type==='add_media_photo_after_audio'){const q=db.questions.find(x=>x.id===st.id);if(!q)return; q.photo=ctx.message.photo[ctx.message.photo.length-1].file_id;saveDB();states.delete(ctx.from.id);return ctx.reply('✅ Soal + media berhasil disimpan.',questionMenu());}
});
bot.on('audio',async ctx=>{
 const st=states.get(ctx.from.id);if(!st||!isAdmin(ctx.from.id))return;
 if(st.type==='replace_audio'){const q=db.questions.find(x=>x.id===st.id);if(!q)return;q.audio=ctx.message.audio.file_id;saveDB();states.delete(ctx.from.id);return ctx.reply('✅ Audio soal diperbarui.',questionMenu());}
 if(st.type==='batch_media'&&st.queue[st.index]?.kind==='audio'){const q=db.questions.find(x=>x.id===st.queue[st.index].id);if(!q)return; q.audio=ctx.message.audio.file_id;saveDB();advanceBatchMedia(ctx);return continueBatchMedia(ctx);}
 if(st.type==='broadcast_audio'){return broadcastPreview(ctx,{type:'audio',file_id:ctx.message.audio.file_id,caption:ctx.message.caption||''});}
 if(st.type==='add_media_audio'){const q=db.questions.find(x=>x.id===st.id);if(!q)return;q.audio=ctx.message.audio.file_id;saveDB();st.type='add_media_photo_after_audio';states.set(ctx.from.id,st);return ctx.reply('🎧 Audio disimpan. Tambahkan foto juga atau selesaikan.',Markup.inlineKeyboard([[Markup.button.callback('🖼️ TAMBAH FOTO','media_photo:'+st.id)],[Markup.button.callback('⏭️ SELESAI','media_done:'+st.id)]]));}
});
bot.on('voice',async ctx=>{
 const st=states.get(ctx.from.id);if(!st||!isAdmin(ctx.from.id))return;
 if(st.type==='replace_audio'){const q=db.questions.find(x=>x.id===st.id);if(!q)return;q.audio=ctx.message.voice.file_id;saveDB();states.delete(ctx.from.id);return ctx.reply('✅ Audio/Voice soal diperbarui.',questionMenu());}
 if(st.type==='batch_media'&&st.queue[st.index]?.kind==='audio'){const q=db.questions.find(x=>x.id===st.queue[st.index].id);if(!q)return; q.audio=ctx.message.voice.file_id;saveDB();advanceBatchMedia(ctx);return continueBatchMedia(ctx);}
 if(st.type==='broadcast_audio'){return broadcastPreview(ctx,{type:'audio',file_id:ctx.message.voice.file_id,caption:''});}
 if(st.type==='add_media_audio'){const q=db.questions.find(x=>x.id===st.id);if(!q)return;q.audio=ctx.message.voice.file_id;saveDB();states.delete(ctx.from.id);return ctx.reply('✅ Soal + media berhasil disimpan.',questionMenu());}
});

bot.on('text',async ctx=>{
  let st=states.get(ctx.from.id);
  if(st?.type==='user_set_count_custom'){
    const raw=String(ctx.message.text||'').trim(),n=Number(raw),key=st.key;if(!MATERIAL_KEYS.includes(key))return;
    if(!/^\d+$/.test(raw)||n<1||n>100)return ctx.reply('❌ Masukkan angka 1–100.');
    const u=ensureUser(ctx);u.testSettings[key]??={count:DEFAULT_TEST_COUNT,timerMode:'none',time:0};u.testSettings[key].count=n;saveDB();states.delete(ctx.from.id);return ctx.reply(`✅ ${testKeyLabel(key)} sekarang: *${n} soal*.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('⚙️ PENGATURAN TEST','user_material_settings')],[Markup.button.callback('🏠 MENU UTAMA','menu')]])});
  }
  if(st?.type==='user_set_timer_time'){
    const raw=String(ctx.message.text||'').trim(),n=Number(raw),key=st.key;if(!MATERIAL_KEYS.includes(key))return;
    if(!/^\d+$/.test(raw)||n<1||n>3600)return ctx.reply('❌ Masukkan detik 1–3600.');
    const u=ensureUser(ctx);u.testSettings[key]??={count:DEFAULT_TEST_COUNT,timerMode:'none',time:0};u.testSettings[key].time=n;saveDB();states.delete(ctx.from.id);return ctx.reply(`✅ Durasi ${testKeyLabel(key)}: *${formatSeconds(n)}*.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('⏱️ ATUR WAKTU','utimer:'+key)],[Markup.button.callback('⚙️ PENGATURAN TEST','user_material_settings')]])});
  }
  if(st?.type==='set_count_custom'){
    if(!isAdmin(ctx.from.id))return;
    const raw=String(ctx.message.text||'').trim(),n=Number(raw),key=st.key;
    if(!/^\d+$/.test(raw)||n<1||n>100)return ctx.reply('❌ Masukkan angka 1–100.');
    db.settings.testSettings[key].count=n;saveDB();states.delete(ctx.from.id);return ctx.reply(`✅ ${testKeyLabel(key)} sekarang: *${n} soal*.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🔢 JUMLAH SOAL','quiz_count')],[Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]])});
  }
  if(st?.type==='set_timer_time'){
    if(!isAdmin(ctx.from.id))return;
    const raw=String(ctx.message.text||'').trim(),n=Number(raw),key=st.key;
    if(!/^\d+$/.test(raw)||n<1||n>3600)return ctx.reply('❌ Masukkan detik 1–3600.');
    db.settings.testSettings[key].time=n;saveDB();states.delete(ctx.from.id);return ctx.reply(`✅ Durasi ${testKeyLabel(key)}: *${formatSeconds(n)}*.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('⏱️ WAKTU TEST','timer_settings')],[Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]])});
  }

 const t=ctx.message.text.trim();
 if(st?.type==='kanji_add'){
  const parsed=parseKanjiBatch(t);
  if(parsed.error)return ctx.reply(`❌ Format Kanji salah pada baris ${parsed.error.line}.\n\n${parsed.error.text}\n\nGunakan:\nKanji | Bacaan | Arti\n\nContoh:\n春 | はる | musim semi`);
  db.kanjiAdditional.push(...parsed.items);saveDB();states.delete(ctx.from.id);
  return ctx.reply(`✅ <b>${parsed.items.length} kanji</b> berhasil disimpan ke Kanji Lainnya.`,{parse_mode:'HTML',...additionalKanjiMenu(true)});
 }
 if(st?.type==='kanji_delete'){
  const nums=t.split(/[,\s]+/).map(x=>Number(x)).filter(Number.isInteger);
  const all=/^semua$/i.test(t);
  const arr=db.kanjiAdditional||[];
  if(!all&&(!nums.length||nums.some(n=>n<1||n>arr.length)))return ctx.reply(`❌ Nomor Kanji tidak valid. Masukkan contoh: 1 atau 1,3,5`);
  if(!arr.length)return ctx.reply('❌ Belum ada Kanji Lainnya.');
  if(all)db.kanjiAdditional=[];else db.kanjiAdditional=arr.filter((_,i)=>!nums.includes(i+1));
  saveDB();states.delete(ctx.from.id);return ctx.reply(`🗑️ <b>${all?'Semua':nums.length} kanji</b> berhasil dihapus.`,{parse_mode:'HTML',...additionalKanjiMenu(true)});
 }
 if(st?.type==='kanji_edit'){
  const n=Number(t);const item=db.kanjiAdditional?.[n-1];if(!item)return ctx.reply('❌ Nomor Kanji tidak ditemukan.');states.set(ctx.from.id,{type:'kanji_edit_data',index:n-1});return ctx.reply(`✏️ Data saat ini: ${item.character} | ${item.reading||''} | ${item.meaning}\n\nKirim data baru dengan format: Kanji | Bacaan | Arti`);
 }
 if(st?.type==='kanji_edit_data'){
  const parts=t.split('|').map(x=>x.trim());if(parts.length<3)return ctx.reply('❌ Format: Kanji | Bacaan | Arti');const item=db.kanjiAdditional[st.index];if(!item)return ctx.reply('❌ Data tidak ditemukan.');item.character=parts[0];item.reading=parts[1]||'';item.meaning=parts.slice(2).join(' | ');saveDB();states.delete(ctx.from.id);return ctx.reply('✅ Kanji Lainnya berhasil diperbarui.',additionalKanjiMenu(true));
 }
 if(st?.type==='broadcast_text'){return broadcastPreview(ctx,{type:'text',text:t});}
 if(st?.type==='media_type'){
   if(!['1','2'].includes(t))return ctx.reply('Ketik 1 untuk Pilihan Ganda atau 2 untuk Isian.');st.data.type=t==='1'?'choice':'fill';st.type='media_question';states.set(ctx.from.id,st);return ctx.reply('Kirim pertanyaan.');
 }
 if(st?.type==='media_question'){
   const d=st.data;
   if(!d.question){d.question=t;if(d.type==='choice')return ctx.reply('Kirim pilihan dengan format: A | B | C | D');return ctx.reply('Kirim jawaban benar persis.');}
   if(d.type==='choice'&&!d.options){const options=t.split('|').map(x=>x.trim()).filter(Boolean);if(options.length<2||options.length>6)return ctx.reply('❌ Pilihan harus 2–6.');d.options=options;return ctx.reply(`Kirim kunci jawaban: ${options.map((_,i)=>String.fromCharCode(65+i)).join('/')}`);}
   if(d.type==='choice'&&!d.answer){const a=t.toUpperCase();if(!/^[A-F]$/.test(a)||a.charCodeAt(0)-65>=d.options.length)return ctx.reply('❌ Kunci tidak valid.');d.answer=a;return ctx.reply('Kirim penjelasan atau - jika tidak ada.');}
   if(d.type==='fill'&&d.answerText===undefined){d.answerText=t;return ctx.reply('Kirim penjelasan atau - jika tidak ada.');}
   if(d.explanation===undefined){d.explanation=t==='-'?'':t;const id=nextQuestionId();const q={id,quiz:st.quizNo,type:d.type,question:d.question,explanation:d.explanation,photo:null,audio:null};if(d.type==='choice'){q.options=d.options;q.answer=d.answer;}else q.answerText=d.answerText;db.questions.push(q);saveDB();states.set(ctx.from.id,{type:'media_choose',id});return ctx.reply('Media soal opsional. Pilih:',Markup.inlineKeyboard([[Markup.button.callback('🖼️ TAMBAH FOTO','media_photo:'+id)],[Markup.button.callback('🎧 TAMBAH AUDIO','media_audio:'+id)],[Markup.button.callback('⏭️ TANPA MEDIA','media_done:'+id)]]));}
 }
 if(st?.type==='start_name'){
   const name=t.replace(/\s+/g,' ').trim();
   if(name.length<2||name.length>40)return ctx.reply('❌ *Nama harus 2–40 karakter.*\n\n🇮🇩 Silakan masukkan nama yang valid.',{parse_mode:'Markdown'});
   const u=ensureUser(ctx);u.name=name;u.username=ctx.from.username||u.username||'';u.lastActivityAt=new Date().toISOString();saveDB();states.delete(ctx.from.id);
   return ctx.reply(`<blockquote>🎉 <b>Nama berhasil disimpan!</b>\n\n🇯🇵 <b>ようこそ, ${escapeHtml(name)}!</b> 🌸\n🇮🇩 <b>Selamat datang, ${escapeHtml(name)}!</b>\n\n🇮🇩 <b>Nama kamu sudah tersimpan. Mulai sekarang kamu tidak perlu memasukkan nama lagi saat mengerjakan quiz atau test materi.</b>\n\n✨ <b>Silakan pilih menu di bawah ini.</b></blockquote>`,{parse_mode:'HTML',...mainMenu(ctx.from.id)});
 }
 if(st?.type==='test_name'){
   const name=t.replace(/\s+/g,' ').trim();if(name.length<2||name.length>40)return ctx.reply('❌ Nama harus 2–40 karakter.');
   const u=ensureUser(ctx);u.name=name;saveDB();const pending=st.pending;states.delete(ctx.from.id);
   if(pending?.kind==='kana')return launchKanaTest(ctx,pending.value);
   if(pending?.kind==='kanji')return launchKanjiTest(ctx,pending.value);
   if(pending?.kind==='study')return launchStudyTest(ctx,pending.value);
   if(pending?.kind==='vocab')return startVocabTest(ctx,pending.value);
 }
 if(st?.type==='quiz_name'){const name=t.replace(/\s+/g,' ');if(name.length<2||name.length>40)return ctx.reply('❌ Nama harus 2–40 karakter.');const quizNo=st.quizNo||1;states.delete(ctx.from.id);return beginQuiz(ctx,name,quizNo);}
 const s=sessions.get(ctx.from.id);
 if(s&&s.currentId){const q=db.questions.find(x=>x.id===s.currentId);if(q?.type==='fill'&&!s.answered){s.lastAnswer=t;return handleAnswer(ctx,q,t===q.answerText.trim());}}
 if(!isAdmin(ctx.from.id)||!st)return;
 if(st.type==='delete_questions'){
  const input=t.toLowerCase().replace(/hapus/g,'').trim();
  if(input==='semua'){states.set(ctx.from.id,{type:'delete_confirm_all',quizNo:st.quizNo});const count=db.questions.filter(q=>Number(q.quiz)===Number(st.quizNo)).length;return ctx.reply(`⚠️ *KONFIRMASI*\n\nKamu akan menghapus *SEMUA ${count} SOAL QUIZ ${st.quizNo}*.\n\nKetik *HAPUS SEMUA* untuk melanjutkan.`,{parse_mode:'Markdown'});}
  const ids=new Set();
  for(const part of input.split(/[,\s]+/).filter(Boolean)){
    if(/^\d+-\d+$/.test(part)){let [a,b]=part.split('-').map(Number);if(a>b)[a,b]=[b,a];for(let i=a;i<=b;i++)ids.add(i);}
    else if(/^\d+$/.test(part))ids.add(Number(part));
  }
  const valid=[...ids].filter(id=>db.questions.some(q=>q.id===id&&Number(q.quiz)===Number(st.quizNo)));
  if(!valid.length)return ctx.reply('❌ Tidak ada ID soal yang valid. Contoh: `1,2,5` atau `10-30` atau `1 4 9`.');
  st.ids=valid;st.type='delete_confirm';states.set(ctx.from.id,st);return ctx.reply(`⚠️ Yakin hapus *${valid.length} soal*?\n\n${valid.slice(0,40).map(x=>`#${x}`).join(', ')}${valid.length>40?' ...':''}\n\nKetik *YA* untuk menghapus atau *BATAL*.`,{parse_mode:'Markdown'});
}
if(st.type==='delete_confirm_all'){if(t.toLowerCase()!=='hapus semua')return ctx.reply('❌ Ketik persis *HAPUS SEMUA* atau ketik BATAL.',{parse_mode:'Markdown'});const quizNo=Number(st.quizNo||1);db.questions=db.questions.filter(q=>Number(q.quiz)!==quizNo);saveDB();states.delete(ctx.from.id);return ctx.reply(`✅ Semua soal Quiz ${quizNo} berhasil dihapus.`,questionMenu());}
if(st.type==='delete_confirm'){if(t.toLowerCase()!=='ya'){states.delete(ctx.from.id);return ctx.reply('❎ Penghapusan dibatalkan.',questionMenu());}const ids=new Set(st.ids||[]);const before=db.questions.length;db.questions=db.questions.filter(q=>!ids.has(q.id));saveDB();states.delete(ctx.from.id);return ctx.reply(`✅ *${before-db.questions.length} soal berhasil dihapus!*`,{parse_mode:'Markdown',...questionMenu()});}
 if(st.type==='edit_question'){const id=Number(t);const q=db.questions.find(x=>x.id===id&&Number(x.quiz)===Number(st.quizNo));if(!q)return ctx.reply('❌ Soal tidak ditemukan.');st.type='edit_field';st.id=id;states.set(ctx.from.id,st);return ctx.reply(`✏️ Edit soal #${id}\n\nKetik *pertanyaan baru* atau ketik - untuk mempertahankan.`,{parse_mode:'Markdown'});}
 if(st.type==='edit_field'){const q=db.questions.find(x=>x.id===st.id);if(t!=='-')q.question=t;states.delete(ctx.from.id);saveDB();return ctx.reply('✅ Pertanyaan diperbarui. Untuk perubahan pilihan/kunci, gunakan hapus lalu tambah kembali pada versi ini.',questionMenu());}
 if(st.type==='add_admin'){const id=Number(t);if(!Number.isInteger(id))return ctx.reply('❌ Telegram ID tidak valid.');if(!db.admins.includes(id)&&id!==Number(OWNER_ID))db.admins.push(id);saveDB();states.delete(ctx.from.id);return ctx.reply(`✅ ${id} sekarang menjadi admin.`,adminMenu());}
 if(st.type==='remove_admin'){const id=Number(t);db.admins=db.admins.filter(x=>Number(x)!==id);saveDB();states.delete(ctx.from.id);return ctx.reply(`✅ Admin ${id} dihapus.`,adminMenu());}
 if(st.type==='add_question_fast') return handleAddQuestionFast(ctx,t);
 if(st.type==='add_question') return handleAddQuestionText(ctx,st,t);
});

function nextQuestionId(){return db.questions.length?Math.max(...db.questions.map(x=>Number(x.id)||0))+1:1;}
function cleanImportLine(s){return String(s||'').replace(/^\s+|\s+$/g,'');}
function parseFastQuestionBlock(block){
  const lines=String(block||'').split(/\r?\n/).map(cleanImportLine).filter(Boolean);
  if(!lines.length) return {error:'Soal kosong.'};

  // Compact one-line format. Optional final columns: Foto | Audio, using + or -.
  // PG | Pertanyaan | A | B | C | D | Kunci | Penjelasan | Foto | Audio
  if(/^PG\s*\|/i.test(lines[0])){
    const parts=lines[0].split('|').map(cleanImportLine);
    const hasMedia=parts.length>=9 && /^[+-]$/.test(parts[parts.length-2]) && /^[+-]$/.test(parts[parts.length-1]);
    if(hasMedia){
      if(parts.length<9)return {error:'Format PG + media kurang lengkap.'};
      const question=parts[1], photoRequired=parts[parts.length-2]==='+', audioRequired=parts[parts.length-1]==='+', answer=(parts[parts.length-4]||'').toUpperCase(), explanation=parts[parts.length-3]||'';
      const options=parts.slice(2,-4).filter(Boolean);
      if(!question)return {error:'Pertanyaan PG kosong.'};
      if(options.length<2||options.length>6)return {error:`Pilihan PG harus 2–6, terbaca ${options.length}.`};
      if(!/^[A-F]$/.test(answer)||answer.charCodeAt(0)-65>=options.length)return {error:'Kunci PG harus A–F dan sesuai jumlah pilihan.'};
      return {question,type:'choice',options,answer,explanation:explanation==='-'?'':explanation,photoRequired,audioRequired};
    }
    if(parts.length<7)return {error:'Format PG kurang lengkap. Minimal: PG | Pertanyaan | A | B | Kunci.'};
    const answer=(parts[parts.length-1-(parts.length>=8?1:0)]||'').toUpperCase();
    let options, explanation='';
    if(parts.length>=8){ options=parts.slice(2,-2).filter(Boolean); explanation=parts[parts.length-1]||''; }
    else options=parts.slice(2,-1).filter(Boolean);
    const question=parts[1];
    if(!question)return {error:'Pertanyaan PG kosong.'};
    if(options.length<2||options.length>6)return {error:`Pilihan PG harus 2–6, terbaca ${options.length}.`};
    if(!/^[A-F]$/.test(answer)||answer.charCodeAt(0)-65>=options.length)return {error:'Kunci PG harus A–F dan sesuai jumlah pilihan.'};
    return {question,type:'choice',options,answer,explanation:explanation==='-'?'':explanation,photoRequired:false,audioRequired:false};
  }

  if(/^ISIAN\s*\|/i.test(lines[0])){
    const parts=lines[0].split('|').map(cleanImportLine);
    const hasMedia=parts.length>=5 && /^[+-]$/.test(parts[parts.length-2]) && /^[+-]$/.test(parts[parts.length-1]);
    if(hasMedia){
      if(parts.length<5)return {error:'Format ISIAN + media kurang lengkap.'};
      const question=parts[1],answerText=parts[2],photoRequired=parts[parts.length-2]==='+',audioRequired=parts[parts.length-1]==='+',explanation=parts[parts.length-3]||'';
      if(!question||!answerText)return {error:'Pertanyaan atau jawaban ISIAN kosong.'};
      return {question,type:'fill',answerText,explanation:explanation==='-'?'':explanation,photoRequired,audioRequired};
    }
    if(parts.length<3)return {error:'Format ISIAN kurang lengkap.'};
    const question=parts[1],answerText=parts[2],explanation=parts.slice(3).join(' | ')||'';
    if(!question||!answerText)return {error:'Pertanyaan atau jawaban ISIAN kosong.'};
    return {question,type:'fill',answerText,explanation:explanation==='-'?'':explanation,photoRequired:false,audioRequired:false};
  }

  // Multiline fallback.
  const type=lines[0].toUpperCase();
  if(type==='PG'){
    if(lines.length<4)return {error:'Format PG baris kurang lengkap.'};
    const options=lines[2].split('|').map(cleanImportLine).filter(Boolean),answer=lines[3].toUpperCase();
    if(options.length<2||options.length>6)return {error:'Pilihan PG harus 2–6 dan dipisahkan dengan |.'};
    if(!/^[A-F]$/.test(answer)||answer.charCodeAt(0)-65>=options.length)return {error:'Kunci PG tidak valid.'};
    return {question:lines[1],type:'choice',options,answer,explanation:(lines[4]||'')==='-'?'':(lines[4]||'')};
  }
  if(type==='ISIAN'){
    if(lines.length<3)return {error:'Format ISIAN baris kurang lengkap.'};
    return {question:lines[1],type:'fill',answerText:lines[2],explanation:(lines[3]||'')==='-'?'':(lines[3]||'')};
  }
  return {error:'Awalan harus PG atau ISIAN.'};
}

function parseFastQuestions(text){
  const raw=String(text||'').replace(/\r/g,'').trim();
  if(!raw)return {items:[],errors:['Pesan kosong.']};

  // Telegram text messages are limited to 4096 characters. We cannot recover
  // characters that Telegram never delivered, so make the limitation explicit.
  const warnings=[];
  if(raw.length>=3900) warnings.push(`Pesan berisi ${raw.length} karakter. Batas pesan Telegram sekitar 4096 karakter; jika ada soal yang tidak ikut terkirim, kirim sisanya sebagai pesan berikutnya.`);

  // Accept all common separators, and also accept one compact PG/ISIAN record
  // per line. This prevents valid questions from being silently swallowed.
  let blocks=raw.split(/(?:^|\n)\s*---+\s*(?:\n|$)/m).map(x=>x.trim()).filter(Boolean);
  if(blocks.length===1 && /\n\s*(?:PG|ISIAN)\s*\|/i.test(raw)){
    blocks=raw.split(/\n(?=\s*(?:PG|ISIAN)\s*\|)/i).map(x=>x.trim()).filter(Boolean);
  }
  // If blank lines are used between records, split them too. A block containing
  // a multiline question format is preserved when it starts with PG/ISIAN alone.
  if(blocks.length===1 && /\n\s*\n/.test(raw) && !/^\s*(?:PG|ISIAN)\s*\|/i.test(raw)){
    blocks=raw.split(/\n\s*\n+/).map(x=>x.trim()).filter(Boolean);
  }

  const items=[],errors=[];
  blocks.forEach((b,i)=>{
    const q=parseFastQuestionBlock(b);
    if(q.error) errors.push(`Soal ${i+1}: ${q.error}`); else items.push(q);
  });
  return {items,errors,warnings,receivedBlocks:blocks.length};
}

async function handleAddQuestionFast(ctx,t){
  const parsed=parseFastQuestions(t);
  if(!parsed.items.length)return ctx.reply('❌ Tidak ada soal yang berhasil dibaca.\n\nKirim ulang memakai format PG | ... atau ISIAN | ...');
  let id=nextQuestionId();
  const added=[];
  const quizNo=Number(states.get(ctx.from.id)?.quizNo||1);
  for(const q of parsed.items){
    const obj={id:id++,quiz:quizNo,type:q.type,question:q.question,explanation:q.explanation||'',photo:null,audio:null,photoRequired:!!q.photoRequired,audioRequired:!!q.audioRequired};
    if(q.type==='choice'){obj.options=q.options;obj.answer=q.answer;}else obj.answerText=q.answerText;
    db.questions.push(obj);added.push(obj);
  }
  saveDB(); states.delete(ctx.from.id);
  const photoQueue=added.filter(q=>q.photoRequired),audioQueue=added.filter(q=>q.audioRequired);
  const none=added.filter(q=>!q.photoRequired&&!q.audioRequired).length;
  const lines=[`📋 *DATA SOAL TERBACA*`,``,`✅ Total: *${added.length} soal*`,`🖼️ Membutuhkan foto: *${photoQueue.length}*`,`🔊 Membutuhkan audio: *${audioQueue.length}*`,`📦 Tanpa media: *${none}*`,``,`📚 Quiz: *${quizNo}*`];
  if(parsed.errors.length)lines.push('',`⚠️ *${parsed.errors.length} bagian gagal:*`,...parsed.errors.slice(0,20));
  if(parsed.warnings.length)lines.push('',`💡 *PERHATIAN*`,...parsed.warnings);
  if(photoQueue.length||audioQueue.length){
    const queue=[...photoQueue.map(q=>({id:q.id,kind:'photo'})),...audioQueue.map(q=>({id:q.id,kind:'audio'}))];
    states.set(ctx.from.id,{type:'batch_media',queue,index:0,quizNo});
    await ctx.reply(lines.join('\n'),{parse_mode:'Markdown'});
    return continueBatchMedia(ctx);
  }
  lines.push('','💡 Semua soal langsung tersimpan karena tidak membutuhkan media.');
  return ctx.reply(lines.join('\n'),{parse_mode:'Markdown',...questionMenu()});
}
async function continueBatchMedia(ctx){
  const st=states.get(ctx.from.id);
  if(!st||st.type!=='batch_media')return;
  while(st.index<st.queue.length){
    const item=st.queue[st.index],q=db.questions.find(x=>x.id===item.id);
    if(!q){st.index++;continue;}
    const label=item.kind==='photo'?'🖼️ FOTO':'🔊 AUDIO';
    const total=st.queue.length;
    return ctx.reply(`${label} *SOAL ${st.index+1}/${total}*\n\n#${q.id} — ${q.question}\n\nSilakan kirim ${item.kind==='photo'?'foto':'audio/voice'} untuk soal ini.`,{parse_mode:'Markdown'});
  }
  states.delete(ctx.from.id);
  saveDB();
  return ctx.reply('✅ *SEMUA MEDIA BERHASIL DISIMPAN!*\n\nSeluruh soal batch sudah lengkap dan siap digunakan.',{parse_mode:'Markdown',...questionMenu()});
}
function advanceBatchMedia(ctx){
  const st=states.get(ctx.from.id); if(st?.type!=='batch_media')return false; st.index++; states.set(ctx.from.id,st); return true;
}

async function handleAddQuestionText(ctx,st,t){
 const q=st.data; if(st.step==='type'){if(!['1','2'].includes(t))return ctx.reply('Ketik 1 untuk PILIHAN GANDA atau 2 untuk ISIAN.');q.type=t==='1'?'choice':'fill';st.step='question';return ctx.reply('2/5 — Kirim pertanyaan.');}
 if(st.step==='question'){q.question=t;if(q.type==='choice'){st.step='options';return ctx.reply('3/5 — Kirim pilihan dipisahkan dengan |. Contoh: satu | dua | tiga | empat. Bisa 2–6 pilihan.');}st.step='answerText';return ctx.reply('3/5 — Kirim jawaban benar persis (isian).');}
 if(st.step==='options'){const options=t.split('|').map(x=>x.trim()).filter(Boolean);if(options.length<2||options.length>6)return ctx.reply('❌ Pilihan harus 2–6 opsi. Pisahkan dengan |.');q.options=options;st.step='answer';return ctx.reply(`4/5 — Kirim huruf jawaban benar: ${options.map((x,i)=>String.fromCharCode(65+i)).join('/')}.`);}
 if(st.step==='answer'){const a=t.toUpperCase();if(!/^[A-F]$/.test(a)||a.charCodeAt(0)-65>=q.options.length)return ctx.reply('❌ Kunci tidak valid.');q.answer=a;st.step='explanation';return ctx.reply('5/5 — Kirim penjelasan atau - jika tidak ada.');}
 if(st.step==='answerText'){q.answerText=t;st.step='explanation';return ctx.reply('4/4 — Kirim penjelasan atau - jika tidak ada.');}
 if(st.step==='explanation'){q.explanation=t==='-'?'':t;const id=db.questions.length?Math.max(...db.questions.map(x=>x.id))+1:1;const obj={id,quiz:Number(st.quizNo||1),type:q.type,question:q.question,explanation:q.explanation};if(q.type==='choice'){obj.options=q.options;obj.answer=q.answer;}else obj.answerText=q.answerText;db.questions.push(obj);saveDB();states.delete(ctx.from.id);return ctx.reply(`✅ *SOAL #${id} TERSIMPAN!*`,{parse_mode:'Markdown',...questionMenu()});}
}

bot.action('my_score',async ctx=>{await ctx.answerCbQuery();const u=ensureUser(ctx),a=u.total_questions?Math.round(u.correct/u.total_questions*100):0;await editScreen(ctx, `📊 *SKOR SAYA*\n\n👤 ${u.name||'Belum ada nama'}\n🎮 Quiz: ${u.games}\n📝 Soal: ${u.total_questions}\n✅ Benar: ${u.correct}\n❌ Salah: ${u.total_questions-u.correct}\n⭐ Poin: ${u.points}\n🎯 Akurasi: ${a}%`,{parse_mode:'Markdown',...back()});});
bot.action('top_score',async ctx=>{await ctx.answerCbQuery();const rows=[...db.users].filter(x=>x.games>0).sort((a,b)=>b.points-a.points).slice(0,10),med=['🥇','🥈','🥉'],lines=['🏆 *SKOR TERTINGGI*','','🔥 10 pemain terbaik:',''];rows.forEach((r,i)=>lines.push(`${med[i]||`${i+1}.`} *${r.name||'Tanpa Nama'}* — ⭐ ${r.points}`));if(!rows.length)lines.push('Belum ada yang menyelesaikan quiz.');await editScreen(ctx, lines.join('\n'),{parse_mode:'Markdown',...back()});});
bot.action('developer',async ctx=>{await ctx.answerCbQuery();await editScreen(ctx, '👨‍💻 *DEVELOPER*\n\n🏪 *Witama Store.ID*\n👤 *@xtera09*\n\n🇯🇵 Nihon Quiz dibuat dan dikembangkan oleh Witama Store.ID.',{parse_mode:'Markdown',...back()});});

function kanjiLevelLabel(l){return ({N5:'🟢',N4:'🔵',N3:'🟡',N2:'🟠',N1:'🔴'})[l]||'🈶'}
function kanjiMenu(level,page=0){const rows=[[Markup.button.callback('📝 TEST KANJI','kanji_test_select')],[Markup.button.callback('⚙️ ATUR TEST','user_material_settings')],[Markup.button.callback('🟢 N5','kanji_n5'),Markup.button.callback('🔵 N4','kanji_n4')],[Markup.button.callback('🟡 N3','kanji_n3'),Markup.button.callback('🟠 N2','kanji_n2')],[Markup.button.callback('🔴 N1','kanji_n1'),Markup.button.callback('🈶 KANJI LAINNYA','kanji_additional')]];const total=Math.max(1,Math.ceil((kanjiLevels[level]||[]).length/15));if(total>1)rows.push([Markup.button.callback('⬅️','kpage:'+level+':'+Math.max(0,page-1)),Markup.button.callback(`${page+1}/${total}`,'noop'),Markup.button.callback('➡️','kpage:'+level+':'+Math.min(total-1,page+1))]);rows.push([Markup.button.callback('🏠 MENU UTAMA','menu')]);return Markup.inlineKeyboard(rows)}
function parseKanjiBatch(text){
 const lines=String(text||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean),items=[];
 for(let i=0;i<lines.length;i++){
  const raw=lines[i],parts=raw.split('|').map(x=>x.trim());
  if(parts.length<3||!parts[0]||!parts[2])return {error:{line:i+1,text:raw}};
  const character=parts[0].replace(/^\d+\s*[.\)\-:]\s*/,'').trim();
  if(!character)return {error:{line:i+1,text:raw}};
  items.push({character,reading:parts[1]||'',meaning:parts.slice(2).join(' | ')});
 }
 return {items};
}
function normalizeAdditionalKanjiData(){
 const arr=db.kanjiAdditional||[];if(arr.length!==1)return false;const x=arr[0];
 const combined=[x.character,x.reading,x.meaning].join(' | ');if(!/\n\s*\d+\s*[.\)]/.test(combined)||!combined.includes('|'))return false;
 const parsed=parseKanjiBatch(combined);if(parsed.error||parsed.items.length<2)return false;
 db.kanjiAdditional=parsed.items;saveDB();return true;
}
function additionalKanjiMenu(admin=false){
 const rows=[[Markup.button.callback('📝 TEST KANJI LAINNYA','kt:additional')]];
 if(admin)rows.push([Markup.button.callback('⚙️ KELOLA KANJI','kanji_admin')]);
 rows.push([Markup.button.callback('🔙 KEMBALI','kanji_menu')]);return Markup.inlineKeyboard(rows);
}
function quoteBlock(lines){return lines.map(x=>`<blockquote>${String(x).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</blockquote>`).join('\n');}
function showKanji(level,page=0){const arr=kanjiLevels[level]||[],per=15,start=page*per,part=arr.slice(start,start+per);let t=`${kanjiLevelLabel(level)} <b>KANJI ${level}</b>\n\nTotal: <b>${arr.length} kanji</b>\nHalaman: <b>${page+1}/${Math.max(1,Math.ceil(arr.length/per))}</b>\n\n`;t+=part.length?part.map((x,i)=>`<blockquote>🇯🇵 ${start+i+1}. <b>${escapeHtml(x[0])}</b> — ${escapeHtml(x[1]||'')}\n🇮🇩 <b>Arti:</b> ${escapeHtml(x[2]||'')}\n${x[3]?escapeHtml(x[3]+' goresan'):''}</blockquote>`).join('\n'):'⚠️ Data level ini belum termuat.';return t}
function escapeHtml(v){return String(v??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
async function ensureKanji(){const total=KANJI_LEVELS.reduce((n,l)=>n+(kanjiLevels[l]?.length||0),0);if(total<2000)await fetchKanjiLevels()}
function additionalKanjiText(){normalizeAdditionalKanjiData();const a=db.kanjiAdditional||[];return `🈶 <b>KANJI LAINNYA</b>\n\n🇮🇩 <b>Total:</b> ${a.length} kanji\n\n${a.length?a.map((x,i)=>`<blockquote>🇯🇵 <b>${i+1}. ${escapeHtml(x.character)}</b> — ${escapeHtml(x.reading||'')}\n🇮🇩 <b>Arti:</b> ${escapeHtml(x.meaning||'')}</blockquote>`).join('\n'):'🇮🇩 Belum ada data Kanji Lainnya.'}`}
function additionalKanjiOptions(){return db.kanjiAdditional||[];}
async function showKanjiQuestion(ctx){const s=sessions.get(ctx.from.id);if(!s||s.type!=='kanji')return;if(s.index>=s.items.length){clearSessionTimer(s);const total=s.items.length,acc=Math.round(s.correct/total*100);const report=prettyReport('HASIL DATA — TEST KANJI',userLabel(ctx),[`📚 Jenis         : Test Kanji`,`🈶 Level         : ${s.kind}`,`📝 Jumlah soal   : ${total}`,`✅ Benar         : ${s.correct}`,`❌ Salah         : ${total-s.correct}`,`🎯 Akurasi       : ${acc}%`,`🕒 Selesai       : ${new Date().toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})}`],s.mistakes);await sendDataChannel(ctx,report);sessions.delete(ctx.from.id);return ctx.reply(`🎊 *TEST KANJI SELESAI!*\n\nLevel: ${s.kind}\nBenar: ${s.correct}\nSalah: ${total-s.correct}\nAkurasi: ${acc}%`,{parse_mode:'Markdown',...back()});}const k=s.items[s.index],opts=shuffle([k.meaning||k[2],...shuffle(s.items.filter((_,i)=>i!==s.index)).slice(0,3).map(x=>x.meaning||x[2])]);s.answer=opts.indexOf(k.meaning||k[2]);await editActiveQuestion(ctx,s,`🈶 *KANJI ${s.kind}*\n\nSoal ${s.index+1}/${s.items.length}\n\n*${k.character||k[0]}* (${k.reading||k[1]||''})\n\nPilih arti:`,{parse_mode:'Markdown',...Markup.inlineKeyboard(opts.map((x,i)=>[Markup.button.callback(`${String.fromCharCode(65+i)}. ${x}`,`ka:${i}`)]))});const timeout=async()=>{if(!s.answered){s.answered=true;s.index++;await showKanjiQuestion(ctx);}};if(s.timerMode==='per_question')await startSessionTimer(ctx,s,'question',s.timerTime,timeout);else if(s.timerMode==='per_quiz'&&!s.timerStarted){s.timerStarted=true;await startSessionTimer(ctx,s,'quiz',s.timerTime,async()=>{s.index=s.items.length;await showKanjiQuestion(ctx);});}}
bot.action('kanji_menu',async ctx=>{await ctx.answerCbQuery();await ensureKanji();await editScreen(ctx,'🈶 <b>KANJI</b>\n\nPilih level atau Kanji Lainnya.',{parse_mode:'HTML',...kanjiMenu('N5',0)});});
bot.action(/^kanji_n([1-5])$/,async ctx=>{
 await ctx.answerCbQuery(); const level='N'+ctx.match[1]; await ensureKanji();
 await editScreen(ctx,showKanji(level,0),{parse_mode:'HTML',...kanjiMenu(level,0)});
});
bot.action(/^kpage:(N[1-5]):(\d+)$/,async ctx=>{
 await ctx.answerCbQuery(); const level=ctx.match[1],page=Number(ctx.match[2]); await ensureKanji();
 await editScreen(ctx,showKanji(level,page),{parse_mode:'HTML',...kanjiMenu(level,page)});
});
bot.action('kanji_additional',async ctx=>{
 await ctx.answerCbQuery(); normalizeAdditionalKanjiData(); await editScreen(ctx,additionalKanjiText(),{parse_mode:'HTML',...additionalKanjiMenu(isAdmin(ctx.from.id))});
});
bot.action('kanji_test_select',async ctx=>{
 await ctx.answerCbQuery(); await ensureKanji();
 const rows=[['N5','N4'],['N3','N2'],['N1','Lainnya']].map(pair=>pair.map(x=>Markup.button.callback('TEST '+x,x==='Lainnya'?'kt:additional':'kt:'+x)));
 rows.push([Markup.button.callback('🔙 KEMBALI','kanji_menu')]);
 await editScreen(ctx,'🈶 <b>TEST KANJI</b>\n\nPilih level yang ingin diuji.',{parse_mode:'HTML',...Markup.inlineKeyboard(rows)});
});
bot.action(/^kt:(N[1-5]|additional)$/,async ctx=>{await ctx.answerCbQuery();const kind=ctx.match[1];if(await requireTestName(ctx,{kind:'kanji',value:kind}))return;return launchKanjiTest(ctx,kind);});
bot.action(/^ka:(\d)$/,async ctx=>{
 await ctx.answerCbQuery(); const s=sessions.get(ctx.from.id); if(!s||s.type!=='kanji')return;
 clearSessionTimer(s); const idx=Number(ctx.match[1]),k=s.items[s.index],ok=idx===s.answer;
 const opts=ctx.callbackQuery.message.reply_markup?.inline_keyboard||[];
 const userAnswer=buttonLabel(ctx,`ka:${idx}`,`Pilihan ${String.fromCharCode(65+idx)}`);
 const correct=k.meaning; const correctAnswer=`${String.fromCharCode(65+s.answer)}. ${correct}`;
 if(ok)s.correct++; else s.mistakes.push({kanji:k.character,kana:k.reading,userAnswer,correctAnswer});
 recordAnswer(ctx,s,{question_id:null,question:`${k.character||''} (${k.reading||''})`,type:'kanji',correct:ok,user_answer:userAnswer,correct_answer:correctAnswer});
 s.index++; return showKanjiQuestion(ctx);
});

bot.action(/^kana:(hiragana|katakana)$/,async ctx=>{await ctx.answerCbQuery();const kind=ctx.match[1];await editScreen(ctx,showKana(kind,0),{parse_mode:'HTML',...kanaMenu(kind,0)});});
bot.action(/^kna_page:(hiragana|katakana):(\d+)$/,async ctx=>{await ctx.answerCbQuery();const kind=ctx.match[1],page=Number(ctx.match[2]);await editScreen(ctx,showKana(kind,page),{parse_mode:'HTML',...kanaMenu(kind,page)});});
bot.action(/^kana_test:(hiragana|katakana)$/,async ctx=>{await ctx.answerCbQuery();const kind=ctx.match[1];if(await requireTestName(ctx,{kind:'kana',value:kind}))return;return launchKanaTest(ctx,kind);});
bot.action('kanastart',async ctx=>{await ctx.answerCbQuery();return showKanaQuestion(ctx);});
async function showKanaQuestion(ctx){
 const s=sessions.get(ctx.from.id);if(!s||s.type!=='kana')return;
 if(s.index>=s.items.length){const total=s.items.length,acc=Math.round(s.correct/total*100);const title=s.kind==='hiragana'?'Hiragana':'Katakana';const report=prettyReport('HASIL DATA — TEST '+title,userLabel(ctx,s.name||ensureUser(ctx).name||ctx.from.first_name||''),[`🔤 Jenis         : Test ${title}`,`📝 Jumlah soal   : ${total}`,`✅ Benar         : ${s.correct}`,`❌ Salah         : ${total-s.correct}`,`🎯 Akurasi       : ${acc}%`,`🕒 Selesai       : ${new Date().toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})}`],s.mistakes);await sendDataChannel(ctx,report);sessions.delete(ctx.from.id);return ctx.reply(`🎊 *TEST ${title} SELESAI!*\n\n✅ Benar: ${s.correct}\n❌ Salah: ${total-s.correct}\n🎯 Akurasi: ${acc}%`,{parse_mode:'Markdown',...back()});}
 const item=s.items[s.index],others=shuffle(s.items.filter(x=>x!==item)).slice(0,3).map(x=>x[1]);const opts=shuffle([item[1],...others]);s.answer=opts.indexOf(item[1]);await editActiveQuestion(ctx,s,`🔤 *TEST ${s.kind==='hiragana'?'HIRAGANA':'KATAKANA'}*\n\nSoal ${s.index+1}/${s.items.length}\n\nHuruf: *${item[0]}*\n\nPilih cara baca:`,{parse_mode:'Markdown',...Markup.inlineKeyboard(opts.map((x,i)=>[Markup.button.callback(`${String.fromCharCode(65+i)}. ${x}`,`kanaans:${i}`)]))});const timeout=async()=>{if(!s.answered){s.answered=true;s.index++;await showKanaQuestion(ctx);}};if(s.timerMode==='per_question')await startSessionTimer(ctx,s,'question',s.timerTime,timeout);else if(s.timerMode==='per_quiz'&&!s.timerStarted){s.timerStarted=true;await startSessionTimer(ctx,s,'quiz',s.timerTime,async()=>{s.index=s.items.length;await showKanaQuestion(ctx);});}
}
bot.action(/^kanaans:(\d)$/,async ctx=>{await ctx.answerCbQuery();const s=sessions.get(ctx.from.id);if(!s||s.type!=='kana')return;clearSessionTimer(s);const idx=Number(ctx.match[1]),item=s.items[s.index],ok=idx===s.answer;const opts=ctx.callbackQuery.message.reply_markup?.inline_keyboard||[];const userAnswer=buttonLabel(ctx,`kanaans:${idx}`,`Pilihan ${String.fromCharCode(65+idx)}`);const correctAnswer=`${String.fromCharCode(65+s.answer)}. ${item[1]}`;if(ok)s.correct++;else s.mistakes.push({kana:item[0],userAnswer,correctAnswer});recordAnswer(ctx,s,{question_id:null,question:`${item[0]} → ${item[1]}`,type:'kana',correct:ok,user_answer:userAnswer,correct_answer:correctAnswer});s.index++;return showKanaQuestion(ctx);});


// Study vocabulary: verbs, nouns, な-adjectives, い-adjectives.
const STUDY_META={
  verbs:{title:'KATA KERJA',emoji:'',data:STUDY_DATA.verbs},
  nouns:{title:'KATA BENDA',emoji:'',data:STUDY_DATA.nouns},
  na:{title:'KATA SIFAT な',emoji:'',data:STUDY_DATA.na_adjectives},
  i:{title:'KATA SIFAT い',emoji:'',data:STUDY_DATA.i_adjectives}
};
function studyPageKeyboard(kind,page=0){
  const meta=STUDY_META[kind], per=8, total=Math.max(1,Math.ceil(meta.data.length/per));
  const rows=[[Markup.button.callback('📝 TEST '+meta.title,'studytest:'+kind)],[Markup.button.callback('⚙️ ATUR TEST','user_material_settings')]];
  if(kind!=='verbs') rows.push([Markup.button.callback('🟣 🇯🇵 動詞 • 🇮🇩 KATA KERJA','study:verbs'),Markup.button.callback('🟤 🇯🇵 名詞 • 🇮🇩 KATA BENDA','study:nouns')]);
  else rows.push([Markup.button.callback('🟢 SIFAT な','study:na'),Markup.button.callback('🔵 SIFAT い','study:i')]);
  const nav=[];
  if(page>0)nav.push(Markup.button.callback('⬅️','studypage:'+kind+':'+(page-1)));
  nav.push(Markup.button.callback(`${page+1}/${total}`,'noop'));
  if(page<total-1)nav.push(Markup.button.callback('➡️','studypage:'+kind+':'+(page+1)));
  if(total>1)rows.push(nav);
  rows.push([Markup.button.callback('🏠 MENU UTAMA','menu')]);
  return Markup.inlineKeyboard(rows);
}
function showStudy(kind,page=0){
  const meta=STUDY_META[kind], data=meta.data, per=8, start=page*per, part=data.slice(start,start+per);
  let text=`<b>${meta.title}</b>\n\nTotal: <b>${data.length} kata</b>\nHalaman: <b>${page+1}/${Math.max(1,Math.ceil(data.length/per))}</b>\n\n`;
  if(kind==='verbs') text+=part.map((x,i)=>`<blockquote>🇯🇵 <b>${start+i+1}. ${escapeHtml(x.kanji)}（${escapeHtml(x.kana)}）</b>\n\n🇮🇩 <b>Arti:</b> ${escapeHtml(x.meaning)}\n\n🍁 <b>Bentuk Kata Kerja</b>\n🇯🇵 <b>ます</b>：${escapeHtml(x.masuKana)}\n🇯🇵 <b>て</b>：${escapeHtml(x.teKana)}\n🇯🇵 <b>辞書形</b>：${escapeHtml(x.dictionaryKana)}\n🇯🇵 <b>ない</b>：${escapeHtml(x.naiKana)}\n🇯🇵 <b>た</b>：${escapeHtml(x.taKana)}</blockquote>`).join('\n');
  else text+=part.map((x,i)=>`<blockquote>${start+i+1}. <b>${escapeHtml(x.kanji)}</b> — ${escapeHtml(x.kana)}\n${escapeHtml(x.meaning)}</blockquote>`).join('\n');
  return text;
}
function studyTestText(ctx,kind){
  const meta=STUDY_META[kind];
  return `📝 *TEST ${meta.title}*\n\nBank soal: *${meta.data.length} kata*\nSoal akan diacak.\nJumlah soal: *${userTestSetting(ctx,kind).count}*`;
}
function studyPrompt(item,kind,target){
  if(kind==='verbs'){
    if(target==='meaning') return `🟣 *TEST KATA KERJA*\n\nSoal: ${item.no}/10\n\n*${item.kanji}* — ${item.kana}\n\n🇮🇩 Pilih arti:`;
    const labels={masu:'bentuk sopan / ます',te:'bentuk て',dictionary:'bentuk kamus',nai:'bentuk ない',ta:'bentuk た'};
    return `🟣 *TEST KATA KERJA*\n\nSoal: ${item.no}/10\n\nKata kerja: *${item.kanji}* — ${item.kana}\n\n❓ Pilih ${labels[target]}:`;
  }
  const title=STUDY_META[kind].title;
  return `${STUDY_META[kind].emoji} *TEST ${title}*\n\nSoal: ${item.no}/10\n\n*${item.kanji}* — ${item.kana}\n\n🇮🇩 Pilih arti:`;
}
function makeStudyOptions(s,item,kind,target){
  let correct;
  if(kind==='verbs') correct=target==='meaning'?item.meaning:item[target+'Kana'];
  else correct=item.meaning;
  const pool=STUDY_META[kind].data.filter(x=>x!==item);
  let distractors;
  if(kind==='verbs' && target!=='meaning') distractors=shuffle(pool).slice(0,3).map(x=>x[target+'Kana']);
  else distractors=shuffle(pool).slice(0,3).map(x=>x.meaning);
  return {correct,opts:shuffle([correct,...distractors])};
}
function studyReport(ctx,s){
  const meta=STUDY_META[s.kind], total=s.items.length, acc=Math.round(s.correct/total*100);
  return prettyReport('HASIL DATA — TEST '+meta.title,userLabel(ctx,s.name||ensureUser(ctx).name||ctx.from.first_name||''),[`📚 Jenis         : Test ${meta.title}`,`📝 Jumlah soal   : ${total}`,`✅ Benar         : ${s.correct}`,`❌ Salah         : ${total-s.correct}`,`🎯 Akurasi       : ${acc}%`,`🕒 Selesai       : ${new Date().toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})}`],s.mistakes);
}
async function showStudyQuestion(ctx){
  const s=sessions.get(ctx.from.id); if(!s||s.type!=='study')return;
  if(s.index>=s.items.length){
    const total=s.items.length,acc=total?Math.round(s.correct/total*100):0;
    await sendDataChannel(ctx,studyReport(ctx,s)); sessions.delete(ctx.from.id);
    return ctx.reply(`🎊 *TEST ${STUDY_META[s.kind].title} SELESAI!*\n\n✅ Benar: ${s.correct}\n❌ Salah: ${total-s.correct}\n🎯 Akurasi: ${acc}%`,{parse_mode:'Markdown',...back()});
  }
  const v=s.items[s.index];
  let target='meaning';
  if(s.kind==='verbs') target=shuffle(['meaning','masu','te','dictionary','nai','ta'])[0];
  const {correct,opts}=makeStudyOptions(s,v,s.kind,target);
  s.answer=opts.indexOf(correct); s.target=target;
  const item={no:s.index+1,kanji:v.kanji,kana:v.kana,meaning:v.meaning};
  await editActiveQuestion(ctx,s,studyPrompt(item,s.kind,target),{parse_mode:'Markdown',...Markup.inlineKeyboard(opts.map((x,i)=>[Markup.button.callback(`${String.fromCharCode(65+i)}. ${x}`,`stans:${i}`)]))});const timeout=async()=>{if(!s.answered){s.answered=true;s.index++;await showStudyQuestion(ctx);}};if(s.timerMode==='per_question')await startSessionTimer(ctx,s,'question',s.timerTime,timeout);else if(s.timerMode==='per_quiz'&&!s.timerStarted){s.timerStarted=true;await startSessionTimer(ctx,s,'quiz',s.timerTime,async()=>{s.index=s.items.length;await showStudyQuestion(ctx);});}
}
for(const kind of ['verbs','nouns','na','i']){
  bot.action('study:'+kind,async ctx=>{await ctx.answerCbQuery();await editScreen(ctx,showStudy(kind,0),{parse_mode:'HTML',...studyPageKeyboard(kind,0)});});
}
bot.action(/^studypage:(verbs|nouns|na|i):(\d+)$/,async ctx=>{await ctx.answerCbQuery();const kind=ctx.match[1],page=Number(ctx.match[2]);await editScreen(ctx,showStudy(kind,page),{parse_mode:'HTML',...studyPageKeyboard(kind,page)});});
bot.action(/^studytest:(verbs|nouns|na|i)$/,async ctx=>{await ctx.answerCbQuery();const kind=ctx.match[1];if(await requireTestName(ctx,{kind:'study',value:kind}))return;return launchStudyTest(ctx,kind);});
bot.action('studystart',async ctx=>{await ctx.answerCbQuery();return showStudyQuestion(ctx);});
bot.action(/^stans:(\d)$/,async ctx=>{
  await ctx.answerCbQuery(); const s=sessions.get(ctx.from.id); if(!s||s.type!=='study')return;
  clearSessionTimer(s);const idx=Number(ctx.match[1]), v=s.items[s.index], ok=idx===s.answer;
  const opts=ctx.callbackQuery.message.reply_markup?.inline_keyboard||[];
  const userAnswer=buttonLabel(ctx,`stans:${idx}`,`Pilihan ${String.fromCharCode(65+idx)}`);
  const correct=s.target==='meaning'?v.meaning:v[s.target+'Kana'];
  const correctAnswer=`${String.fromCharCode(65+s.answer)}. ${correct}`;
  if(ok)s.correct++; else s.mistakes.push({word:v.kanji,kana:v.kana,prompt:s.target,userAnswer,correctAnswer});
  recordAnswer(ctx,s,{question_id:null,question:`${v.kanji||''} (${v.kana||''})`,type:'study',correct:ok,user_answer:userAnswer,correct_answer:correctAnswer});
  s.index++; return showStudyQuestion(ctx);
});

function chapterKeyboard(page=0,selected=[]){
 const start=page*10+1,rows=[];
 for(let i=start;i<Math.min(start+10,51);i++){
  const checked=selected.includes(i);
  rows.push([
    Markup.button.callback(`📖 BAB ${i}`,'vb:'+i),
    Markup.button.callback(`${checked?'☑️':'⬜'} TEST`,`vsel:${i}`)
  ]);
 }
 const nav=[];
 if(page>0)nav.push(Markup.button.callback('⬅️','vpage:'+(page-1)));
 if(page<4)nav.push(Markup.button.callback('➡️','vpage:'+(page+1)));
 if(nav.length)rows.push(nav);
 rows.push([Markup.button.callback('☑️ SEMUA BAB','vselect_all'),Markup.button.callback('🧹 BATAL PILIH','vselect_clear')]);
 rows.push([Markup.button.callback(`🚀 KONFIRMASI (${selected.length})`,'vselect_confirm')],[Markup.button.callback('⚙️ ATUR TEST','user_material_settings')],[Markup.button.callback('🏠 MENU UTAMA','menu')]);
 return Markup.inlineKeyboard(rows);
}
function vocabSelectText(selected){return `📝 *PILIH BAB UNTUK TEST KOSAKATA*\n\nKamu bebas memilih 1 bab, beberapa bab, atau semua bab.\n\nBab terpilih: *${selected.length?selected.join(', '):'belum ada'}*\n\nTekan bab untuk centang/batal centang.`;}
bot.action('vocab',async ctx=>{
  await ctx.answerCbQuery();
  states.delete(ctx.from.id);
  await editScreen(ctx, `📚 *KOSAKATA BAB 1–50*\n\nPilih bab yang ingin kamu buka. Setelah memilih bab, kamu bisa memilih *LIHAT KOSAKATA* atau *TEST KOSAKATA*.\n\n⚙️ Jumlah soal & waktu test Kosakata bisa kamu atur sendiri.`,{parse_mode:'Markdown',...chapterKeyboard(0,[])});
});;
bot.action(/^vpage:(\d)$/,async ctx=>{await ctx.answerCbQuery();const s=states.get(ctx.from.id),selected=s?.type==='vocab_select'?s.selected:[];if(s?.type==='vocab_select')s.page=Number(ctx.match[1]);const p=Number(ctx.match[1]);await editScreen(ctx,vocabSelectText(selected),{parse_mode:'Markdown',...chapterKeyboard(p,selected)});});
bot.action(/^vb:(\d+)$/,async ctx=>{
  await ctx.answerCbQuery(); const n=Number(ctx.match[1]);
  states.set(ctx.from.id,{type:'vocab_chapter',chapter:n});
  let count=''; try { const rows=await getVocabChapter(n); count=`\n\n📦 ${rows.length} kosakata tersedia.`; } catch { count='\n\n⚠️ Data belum berhasil dimuat dari sumber online.'; }
  await editScreen(ctx,`📚 *BAB ${n}*${count}\n\nMau melakukan apa?`,{parse_mode:'Markdown',...Markup.inlineKeyboard([
    [Markup.button.callback('📖 LIHAT KOSAKATA',`vlook:${n}`)],
    [Markup.button.callback('📝 TEST KOSAKATA',`vtestone:${n}`)],
    [Markup.button.callback('⬅️ PILIH BAB','vocab')],
    [Markup.button.callback('🏠 MENU UTAMA','menu')]
  ])});
});
bot.action(/^vlook:(\d+)$/,async ctx=>{
  await ctx.answerCbQuery(); const n=Number(ctx.match[1]);
  let rows=[]; try { rows=await getVocabChapter(n); } catch(e) {
    return editScreen(ctx,`📚 *BAB ${n}*\n\n⚠️ Kosakata belum berhasil dimuat. Pastikan bot memiliki akses internet lalu coba lagi.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🔄 COBA LAGI',`vlook:${n}`)],[Markup.button.callback('⬅️ KEMBALI','vocab')]])});
  }
  const lines=rows.map((x,i)=>`<blockquote>${i+1}. <b>${escapeHtml(x[0])}</b>${x[1]?` — ${escapeHtml(x[1])}`:''}\n${escapeHtml(x[2])}</blockquote>`);
  const text=`📚 <b>KOSAKATA BAB ${n}</b>\n\n${lines.join('\n')}`;
  const kb=Markup.inlineKeyboard([[Markup.button.callback('📝 TEST BAB INI',`vtestone:${n}`)],[Markup.button.callback('⬅️ KEMBALI','vocab')],[Markup.button.callback('🏠 MENU UTAMA','menu')]]);
  if(text.length<=3900) return editScreen(ctx,text,{parse_mode:'HTML',...kb});
  // Telegram text limit is 4096; send the list in safe chunks.
  await ctx.reply(`📚 *KOSAKATA BAB ${n}*`,{parse_mode:'Markdown'});
  for(let i=0;i<lines.length;i+=18) await ctx.reply(lines.slice(i,i+18).join('\n'),{parse_mode:'HTML'});
  return ctx.reply('Pilih tindakan:',kb);
});
bot.action(/^vtestone:(\d+)$/,async ctx=>{
  await ctx.answerCbQuery(); const n=Number(ctx.match[1]);
  states.set(ctx.from.id,{type:'vocab_select',selected:[n],page:Math.floor((n-1)/10)});
  await editScreen(ctx,vocabSelectText([n]),{parse_mode:'Markdown',...chapterKeyboard(Math.floor((n-1)/10),[n])});
});
bot.action('vocab_test_select',async ctx=>{await ctx.answerCbQuery();const selected=[];states.set(ctx.from.id,{type:'vocab_select',selected,page:0});await editScreen(ctx,vocabSelectText(selected),{parse_mode:'Markdown',...chapterKeyboard(0,selected)});});
bot.action(/^vsel:(\d+)$/,async ctx=>{await ctx.answerCbQuery();let s=states.get(ctx.from.id);if(!s||s.type!=='vocab_select'){s={type:'vocab_select',selected:[],page:0};states.set(ctx.from.id,s);}const n=Number(ctx.match[1]);if(s.selected.includes(n))s.selected=s.selected.filter(x=>x!==n);else s.selected.push(n);s.selected.sort((a,b)=>a-b);await editScreen(ctx,vocabSelectText(s.selected),{parse_mode:'Markdown',...chapterKeyboard(s.page,s.selected)});});
bot.action('vselect_all',async ctx=>{await ctx.answerCbQuery();let s=states.get(ctx.from.id);if(!s||s.type!=='vocab_select'){s={type:'vocab_select',selected:[],page:0};states.set(ctx.from.id,s);}s.selected=[...Array(50)].map((_,i)=>i+1);await editScreen(ctx,vocabSelectText(s.selected),{parse_mode:'Markdown',...chapterKeyboard(s.page,s.selected)});});
bot.action('vselect_clear',async ctx=>{await ctx.answerCbQuery();let s=states.get(ctx.from.id);if(!s||s.type!=='vocab_select'){s={type:'vocab_select',selected:[],page:0};states.set(ctx.from.id,s);}s.selected=[];await editScreen(ctx,vocabSelectText([]),{parse_mode:'Markdown',...chapterKeyboard(s.page,[])});});
bot.action('vselect_confirm',async ctx=>{await ctx.answerCbQuery();const s=states.get(ctx.from.id);const selected=s?.type==='vocab_select'?s.selected:[];if(!selected.length)return ctx.reply('❌ Pilih minimal 1 bab dulu.');await editScreen(ctx,`✅ *KONFIRMASI TEST KOSAKATA*\n\nKamu memilih *${selected.length} bab*:\n${selected.join(', ')}\n\nSoal akan diambil secara acak dari semua bab yang dipilih.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🚀 MULAI TEST','vstart')],[Markup.button.callback('⚙️ ATUR TEST','user_material_settings')],[Markup.button.callback('🔙 PILIH LAGI','vocab_test_select')]])});states.set(ctx.from.id,{type:'vocab_confirm',selected});});
bot.action('vstart',async ctx=>{await ctx.answerCbQuery();const s=states.get(ctx.from.id);if(!s||!s.selected?.length)return;if(await requireTestName(ctx,{kind:'vocab',value:s.selected}))return;return startVocabTest(ctx,s.selected);});
async function startVocabTest(ctx,chapters){
  const loaded=await loadVocabChapters(chapters); const pool=[];
  for(const item of loaded) for(const v of item.rows) pool.push({word:v[0],kanji:v[1],meaning:v[2],chapter:item.chapter});
  if(!pool.length){states.delete(ctx.from.id);return ctx.reply('⚠️ Data kosakata belum berhasil dimuat. Coba lagi saat bot terhubung ke internet.');}
  const cfg=userTestSetting(ctx,'vocab');const items=shuffle(pool).slice(0,Math.min(cfg.count,pool.length));
  sessions.set(ctx.from.id,{type:'vocab',items,index:0,correct:0,mistakes:[],startedAt:new Date().toISOString(),timerMode:cfg.timerMode,timerTime:cfg.time,timerStarted:false,name:ensureUser(ctx).name});
 markActivity(ctx,'vocab','Kosakata'); states.delete(ctx.from.id); return showVocabQuestion(ctx);
}
async function showVocabQuestion(ctx){const s=sessions.get(ctx.from.id);if(!s||s.type!=='vocab')return;if(s.index>=s.items.length){const total=s.items.length,acc=Math.round(s.correct/total*100);const report=['📊 HASIL DATA — TEST KOSAKATA','━━━━━━━━━━━━━━━━━━━━',userLabel(ctx,s.name||ensureUser(ctx).name||ctx.from.first_name||''),'Jenis: Test Kosakata',`Bab: ${[...new Set(s.items.map(x=>x.chapter))].join(', ')}`,`Jumlah soal: ${total}`,`Benar: ${s.correct}`,`Salah: ${total-s.correct}`,`Akurasi: ${acc}%`,`Waktu selesai: ${new Date().toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})}`,s.mistakes.length?`\n❌ DETAIL KESALAHAN:\n${s.mistakes.map((m,i)=>`${i+1}. ${m.word}${m.kanji?' — '+m.kanji:''}\n   Jawaban user: ${m.userAnswer}\n   Jawaban benar: ${m.correctAnswer}`).join('\n')}`:'\n✅ Tidak ada jawaban yang salah.'].join('\n');await sendDataChannel(ctx,report);sessions.delete(ctx.from.id);return ctx.reply(`🎊 *TEST KOSAKATA SELESAI!*\n\n✅ Benar: ${s.correct}\n❌ Salah: ${total-s.correct}\n🎯 Akurasi: ${acc}%`,{parse_mode:'Markdown',...back()});}const v=s.items[s.index];const distractors=shuffle(s.items.filter((_,i)=>i!==s.index)).slice(0,3).map(x=>x.meaning);const opts=shuffle([v.meaning,...distractors]);s.answer=opts.indexOf(v.meaning);await editActiveQuestion(ctx,s,`📚 *TEST KOSAKATA*\n\nSoal ${s.index+1}/${s.items.length}\nBab ${v.chapter}\n\n*${v.word}*${v.kanji?` — ${v.kanji}`:''}\n\nPilih arti:`,{parse_mode:'Markdown',...Markup.inlineKeyboard(opts.map((x,i)=>[Markup.button.callback(`${String.fromCharCode(65+i)}. ${x}`,`va:${i}`)]))});const timeout=async()=>{if(!s.answered){s.answered=true;s.index++;await showVocabQuestion(ctx);}};if(s.timerMode==='per_question')await startSessionTimer(ctx,s,'question',s.timerTime,timeout);else if(s.timerMode==='per_quiz'&&!s.timerStarted){s.timerStarted=true;await startSessionTimer(ctx,s,'quiz',s.timerTime,async()=>{s.index=s.items.length;await showVocabQuestion(ctx);});}}
bot.action(/^va:(\d)$/,async ctx=>{await ctx.answerCbQuery();const s=sessions.get(ctx.from.id);if(!s||s.type!=='vocab')return;clearSessionTimer(s);const idx=Number(ctx.match[1]),v=s.items[s.index],ok=idx===s.answer;const opts=ctx.callbackQuery.message.reply_markup?.inline_keyboard||[];const userAnswer=opts.flat().find(b=>b.callback===`va:${idx}`)?.text||`Pilihan ${String.fromCharCode(65+idx)}`;if(ok)s.correct++;else s.mistakes.push({word:v.word,kanji:v.kanji,userAnswer,correctAnswer:v.meaning});recordAnswer(ctx,s,{question_id:null,question:`${v.word}${v.kanji?' — '+v.kanji:''}`,type:'vocab',correct:ok,user_answer:userAnswer,correct_answer:v.meaning});s.index++;return showVocabQuestion(ctx);});
function userMaterialSettingsText(ctx){
  const lines=['⚙️ *PENGATURAN TEST MATERI*','','Pengaturan ini *khusus akun kamu*. User lain tidak ikut berubah.','','📌 Jumlah soal dan waktu bisa berbeda untuk setiap materi.',''];
  for(const k of MATERIAL_KEYS){const c=userTestSetting(ctx,k);lines.push(`• *${testKeyLabel(k)}* — ${c.count} soal • ${timerLabel(c)}`);}
  return lines.join('\n');
}
bot.action('user_material_settings',async ctx=>{
 await ctx.answerCbQuery();
 const rows=[];
 for(let i=0;i<MATERIAL_KEYS.length;i+=2){const a=MATERIAL_KEYS[i],b=MATERIAL_KEYS[i+1];const row=[Markup.button.callback(testKeyLabel(a),`usetpick:${a}`)];if(b)row.push(Markup.button.callback(testKeyLabel(b),`usetpick:${b}`));rows.push(row);}
 rows.push([Markup.button.callback('🏠 MENU UTAMA','menu')]);
 await editScreen(ctx,userMaterialSettingsText(ctx),{parse_mode:'Markdown',...Markup.inlineKeyboard(rows)});
});
bot.action(/^usetpick:(.+)$/,async ctx=>{
 await ctx.answerCbQuery(); const key=ctx.match[1]; if(!MATERIAL_KEYS.includes(key))return; const c=userTestSetting(ctx,key);
 await editScreen(ctx,`⚙️ *${testKeyLabel(key).toUpperCase()}*\n\nSaat ini: *${c.count} soal* • *${timerLabel(c)}*.\n\nPilih jumlah soal atau pengaturan waktu.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🔢 JUMLAH SOAL',`ucount:${key}`)],[Markup.button.callback('⏱️ WAKTU TEST',`utimer:${key}`)],[Markup.button.callback('🔙 SEMUA TEST MATERI','user_material_settings')]])});
});
bot.action(/^ucount:(.+)$/,async ctx=>{await ctx.answerCbQuery();const key=ctx.match[1];if(!MATERIAL_KEYS.includes(key))return;const c=userTestSetting(ctx,key);await editScreen(ctx,`🔢 *JUMLAH SOAL — ${testKeyLabel(key).toUpperCase()}*\n\nSaat ini: *${c.count} soal*.\n\nPilih jumlah:`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('5',`usetcount:${key}:5`),Markup.button.callback('10',`usetcount:${key}:10`),Markup.button.callback('15',`usetcount:${key}:15`)],[Markup.button.callback('20',`usetcount:${key}:20`),Markup.button.callback('30',`usetcount:${key}:30`),Markup.button.callback('50',`usetcount:${key}:50`)],[Markup.button.callback('✏️ CUSTOM',`usetcountcustom:${key}`)],[Markup.button.callback('🔙 KEMBALI',`usetpick:${key}`)]] )});});
bot.action(/^usetcount:(.+):(\d+)$/,async ctx=>{await ctx.answerCbQuery();const key=ctx.match[1],n=Number(ctx.match[2]);if(!MATERIAL_KEYS.includes(key)||n<1||n>100)return;const u=ensureUser(ctx);u.testSettings[key]={...(u.testSettings[key]||{}),count:n};saveDB();await editScreen(ctx,`✅ *JUMLAH SOAL DIPERBARUI*\n\n${testKeyLabel(key)}: *${n} soal*.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🔙 PENGATURAN TEST',`usetpick:${key}`)],[Markup.button.callback('⚙️ SEMUA TEST MATERI','user_material_settings')]])});});
bot.action(/^usetcountcustom:(.+)$/,async ctx=>{await ctx.answerCbQuery();const key=ctx.match[1];if(!MATERIAL_KEYS.includes(key))return;states.set(ctx.from.id,{type:'user_set_count_custom',key});await ctx.reply(`✏️ Jumlah soal untuk *${testKeyLabel(key)}*\n\nKetik angka 1–100.`,{parse_mode:'Markdown'});});
bot.action(/^utimer:(.+)$/,async ctx=>{await ctx.answerCbQuery();const key=ctx.match[1];if(!MATERIAL_KEYS.includes(key))return;const c=userTestSetting(ctx,key);await editScreen(ctx,`⏱️ *WAKTU TEST — ${testKeyLabel(key).toUpperCase()}*\n\nSaat ini: *${timerLabel(c)}*.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('⚪ TANPA BATAS',`usetimer:${key}:none`)],[Markup.button.callback('⏱️ PER SOAL',`usetimer:${key}:per_question`)],[Markup.button.callback('🕐 PER TEST',`usetimer:${key}:per_quiz`)],[Markup.button.callback('✏️ ATUR DETIK',`utime:${key}`)],[Markup.button.callback('🔙 KEMBALI',`usetpick:${key}`)]])});});
bot.action(/^usetimer:(.+):(none|per_question|per_quiz)$/,async ctx=>{await ctx.answerCbQuery();const key=ctx.match[1],mode=ctx.match[2];if(!MATERIAL_KEYS.includes(key))return;const u=ensureUser(ctx);u.testSettings[key]??={count:DEFAULT_TEST_COUNT,time:0,timerMode:'none'};u.testSettings[key].timerMode=mode;if(mode==='none')u.testSettings[key].time=0;saveDB();await editScreen(ctx,`✅ Mode waktu ${testKeyLabel(key)}: *${timerLabel(userTestSetting(ctx,key))}*.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('⏱️ ATUR LAGI',`utimer:${key}`)],[Markup.button.callback('🔙 PENGATURAN TEST',`usetpick:${key}`)]])});});
bot.action(/^utime:(.+)$/,async ctx=>{await ctx.answerCbQuery();const key=ctx.match[1];if(!MATERIAL_KEYS.includes(key))return;states.set(ctx.from.id,{type:'user_set_timer_time',key});await ctx.reply(`⏱️ Durasi *${testKeyLabel(key)}*\n\nKetik detik 1–3600. Contoh: 30 = 30 detik.`,{parse_mode:'Markdown'});});
// ADMIN
bot.action('admin_panel',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx, '👑 *ADMIN PANEL*\n\nOwner dan Admin memiliki hak akses yang sama untuk pengelolaan bot.',{parse_mode:'Markdown',...adminMenu()});});
bot.action('admin_help',async ctx=>{
 await ctx.answerCbQuery();
 if(!isAdmin(ctx.from.id))return;
 const text=`📖 <b>PANDUAN PENGGUNAAN — ADMIN PANEL</b>

<blockquote>👑 <b>Selamat datang, Admin!</b>
Panel ini dipakai untuk mengatur soal, materi, quiz, statistik, broadcast, backup, dan admin bot.</blockquote>

<b>📝 1. KELOLA SOAL</b>
<blockquote>➕ <b>Tambah Soal Cepat</b>
Pilih Quiz 1–20 lalu kirim format soal.

<b>PG:</b>
<code>PG | Pertanyaan | A | B | C | D | Kunci | Penjelasan | Foto | Audio</code>
<code>+ | -</code> = foto diminta, audio tidak.
<code>- | +</code> = foto tidak, audio diminta.
<code>+ | +</code> = foto dan audio diminta.
<code>- | -</code> = tanpa media.

<b>ISIAN:</b>
<code>ISIAN | Pertanyaan | Jawaban benar | Penjelasan | Foto | Audio</code>
Dua kolom terakhir tetap memakai <code>+</code> / <code>-</code>.

➕ <b>Soal + Media</b>
Format cepat mendukung kolom <b>Foto</b> dan <b>Audio</b>: <code>+</code> = bot meminta media setelah batch terbaca, <code>-</code> = tanpa media.
Dipakai jika soal membutuhkan foto dan/atau audio.

✏️ <b>Edit Soal</b>
Pilih Quiz → masukkan ID soal → kirim data pengganti.

🖼️🎧 <b>Edit Media</b>
Pilih Quiz → pilih soal → tambah/ganti/hapus foto atau audio.

🗑️ <b>Hapus Soal</b>
Bisa menghapus beberapa ID sekaligus, rentang ID, atau seluruh soal dalam satu Quiz.

📋 <b>Semua Soal</b>
Melihat daftar soal berdasarkan Quiz.</blockquote>

<b>⚙️ 2. PENGATURAN QUIZ</b>
<blockquote>Atur sistem hasil quiz:
⚡ <b>Langsung</b> → benar/salah ditampilkan setelah menjawab.
📝 <b>Selesaikan Dulu</b> → semua soal dikerjakan dahulu, hasil muncul di akhir.</blockquote>

<b>🔢 3. JUMLAH SOAL</b>
<blockquote>Setiap Quiz 1–20 memiliki jumlah soal sendiri. <b>Test Materi diatur oleh masing-masing user</b>, jadi pengaturan user A tidak mengubah user B.

Pilihan jumlah tersedia melalui tombol. Gunakan <b>Custom</b> bila ingin angka lain.</blockquote>

<b>⏱️ 4. WAKTU TEST</b>
<blockquote>⚪ <b>Tanpa Batas</b> → tidak ada timer.
⏱️ <b>Per Soal</b> → waktu di-reset pada setiap soal.
🕐 <b>Per Quiz</b> → satu timer berjalan untuk seluruh test.

Durasi diatur dalam detik.
Contoh: <code>30</code> = 30 detik, <code>600</code> = 10 menit.</blockquote>

<b>🈶 5. KELOLA KANJI</b>
<blockquote>Menu ini khusus <b>Kanji Lainnya</b> yang kamu masukkan sendiri.
➕ Tambah → <code>Kanji | Bacaan | Arti</code>
✏️ Edit → pilih nomor data.
📋 Lihat → tampilkan data tambahan.
🗑️ Hapus → hapus berdasarkan nomor.

Kanji N1–N5 bawaan tetap tersedia untuk user.</blockquote>

<b>📚 6. TEST MATERI</b>
<blockquote>Pengaturan jumlah dan waktu tersedia untuk:
🔤 Hiragana
🔤 Katakana
🈶 Kanji N5–N1
🈶 Kanji Lainnya
🟣 Kata Kerja
🟤 Kata Benda
🟢 Kata Sifat な
🔵 Kata Sifat い
📚 Kosakata</blockquote>

<b>📢 7. BROADCAST</b>
<blockquote>Kirim pengumuman ke seluruh user yang tersimpan di database.

📝 Teks
🖼️ Foto
🎧 Audio

Bot akan menampilkan <b>preview</b> terlebih dahulu. Tekan <b>✅ KIRIM</b> untuk mengirim atau <b>❌ BATAL</b> untuk membatalkan.</blockquote>

<b>📈 8. STATISTIK</b>
<blockquote>Melihat total user, jawaban, benar/salah, akurasi, poin, total soal, serta statistik tiap user.

Tekan nama user untuk melihat kesalahan secara lebih rinci.</blockquote>

<b>🏆 9. SKOR TERTINGGI</b>
<blockquote>Menampilkan leaderboard berdasarkan poin user yang sudah menyelesaikan quiz.</blockquote>

<b>🗑️ 10. RESET DATA / STATISTIK</b>
<blockquote>📊 <b>Reset Statistik</b> → menghapus skor, poin, jumlah quiz, dan riwayat jawaban.

💥 <b>Reset Data User</b> → menghapus seluruh data user beserta statistik dan riwayat.

⚠️ Soal, Kanji, Kosakata, pengaturan quiz, dan daftar admin tetap aman. Semua reset membutuhkan konfirmasi.</blockquote>

<b>👥 11. KELOLA ADMIN</b>
<blockquote>Owner dapat menambah atau menghapus Admin menggunakan Telegram ID.
Admin dan Owner memiliki hak pengelolaan yang sama untuk fungsi panel.</blockquote>

<b>💾 12. BACKUP</b>
<blockquote><code>/backup</code> → membuat backup project dan mengirimkannya ke Owner.
Backup tidak menyertakan <code>node_modules</code>.
Backup otomatis berjalan sesuai pengaturan <code>AUTO_BACKUP_HOURS</code>.</blockquote>

<b>💡 TIPS AGAR AMAN</b>
<blockquote>1️⃣ Selalu cek Quiz tujuan sebelum menambah soal.
2️⃣ Gunakan format import satu soal dalam satu baris.
3️⃣ Untuk PG, kunci harus berupa <code>A</code>, <code>B</code>, <code>C</code>, atau <code>D</code> sesuai pilihan.
4️⃣ Setelah perubahan besar, lakukan <code>/backup</code>.
5️⃣ Jangan melakukan reset sebelum memastikan data memang ingin dihapus.</blockquote>

<blockquote>🇯🇵 <b>Nihon Quiz</b>
Dikelola oleh <b>Witama Store.ID</b> • @xtera09</blockquote>`;
 const kb=Markup.inlineKeyboard([
  [Markup.button.callback('📝 KELOLA SOAL','admin_questions'),Markup.button.callback('⚙️ PENGATURAN QUIZ','quiz_settings')],
  [Markup.button.callback('🈶 KELOLA KANJI','kanji_admin'),Markup.button.callback('📈 STATISTIK','admin_stats')],
  [Markup.button.callback('📢 BROADCAST','broadcast'),Markup.button.callback('👥 KELOLA ADMIN','admin_manage')],
  [Markup.button.callback('🗑️ RESET DATA','admin_reset')],
  [Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]
 ]);
 return editScreen(ctx,text,{parse_mode:'HTML',...kb});
});

bot.action('admin_manage',async ctx=>{
 await ctx.answerCbQuery();
 if(!isAdmin(ctx.from.id))return;
 const ids=[...new Set([...ADMIN_IDS.map(Number),...db.admins.map(Number)])];
 const list=ids.length?ids.map((x,i)=>`${i+1}️⃣ <code>${x}</code>`).join('\n'):'<i>Belum ada admin tambahan.</i>';
 const text=`<blockquote>👥 <b>KELOLA ADMIN</b> 👑

🇮🇩 <b>Owner dan Admin memiliki hak pengelolaan yang sama.</b>
🇮🇩 <b>Command /backup tetap khusus Owner.</b>

📋 <b>Daftar Admin:</b>
${list}</blockquote>`;
 await editScreen(ctx,text,{parse_mode:'HTML',...Markup.inlineKeyboard([
  [Markup.button.callback('➕ TAMBAH ADMIN','admin_add_admin'),Markup.button.callback('🗑️ HAPUS ADMIN','admin_remove_admin')],
  [Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]
 ])});
});
bot.action('admin_questions',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx, '📝 *KELOLA SOAL*\n\nDua puluh bank soal terpisah: Quiz 1–20. Setiap aksi tambah/edit/hapus/lihat meminta pilihan Quiz.',{parse_mode:'Markdown',...questionMenu()});});
bot.action('admin_add',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx,'➕ *TAMBAH SOAL*\n\nPilih soal akan dimasukkan ke Quiz nomor berapa?',{parse_mode:'Markdown',...quizManageKeyboard('addquiz')});});
bot.action(/^addquiz:(\d{1,2})$/,async ctx=>{
  await ctx.answerCbQuery();
  if(!isAdmin(ctx.from.id))return;
  const quizNo=Number(ctx.match[1]);
  states.set(ctx.from.id,{type:'add_question_fast',quizNo});
  await ctx.reply(
`➕ *TAMBAH SOAL CEPAT + MEDIA*\n\nKirim banyak soal sekaligus dalam satu pesan.\n\n*📸🔊 Kolom media:*\nTambahkan 2 kolom terakhir: *Foto | Audio*\n\`+\` = bot akan meminta media untuk soal tersebut\n\`-\` = tidak membutuhkan media\n\n*📝 FORMAT PILIHAN GANDA:*\n\`PG | Pertanyaan | A | B | C | D | Kunci | Penjelasan | Foto | Audio\`\n\n*Contoh tanpa media:*\n\`PG | Apa arti 猫? | Kucing | Anjing | Burung | Ikan | A | 猫 berarti kucing. | - | -\`\n\n*Contoh foto:*\n\`PG | Ini gambar apa? | 猫 | 犬 | 鳥 | 魚 | A | Jawabannya 猫. | + | -\`\n\n*Contoh audio:*\n\`PG | Dengarkan audio lalu pilih. | あさ | よる | ひる | ばん | A | Jawabannya あさ. | - | +\`\n\n*Contoh foto + audio:*\n\`PG | Apa yang terlihat/terdengar? | A | B | C | D | A | Penjelasan | + | +\`\n\n*📝 FORMAT ISIAN:*\n\`ISIAN | Pertanyaan | Jawaban benar | Penjelasan | Foto | Audio\`\n\nSetelah dikirim, bot akan menampilkan jumlah soal yang membutuhkan *🖼️ foto* dan *🔊 audio*, lalu meminta media satu per satu.\n\nPisahkan beberapa soal dengan baris baru, baris kosong, atau \`---\`.\n\n💡 Kamu bisa tempel 10, 20, bahkan puluhan soal sekaligus.`,
    {parse_mode:'Markdown'}
  );
});
bot.action('admin_add_media',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx,'➕ *SOAL + MEDIA*\n\nPilih Quiz 1–20.',{parse_mode:'Markdown',...quizManageKeyboard('addmediaquiz')});});
bot.action(/^addmediaquiz:(\d{1,2})$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const quizNo=Number(ctx.match[1]);if(quizNo<1||quizNo>20)return;states.set(ctx.from.id,{type:'media_type',quizNo,data:{}});await ctx.reply(`📝 Soal untuk Quiz ${quizNo}.\n\nPilih tipe:\n1 = Pilihan Ganda\n2 = Isian`);});

bot.action(/^media_photo:(\d+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const id=Number(ctx.match[1]);states.set(ctx.from.id,{type:'add_media_photo',id});await ctx.reply('🖼️ Kirim foto untuk soal ini.');});
bot.action(/^media_audio:(\d+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const id=Number(ctx.match[1]);states.set(ctx.from.id,{type:'add_media_audio',id});await ctx.reply('🎧 Kirim audio atau Voice untuk soal ini.');});
bot.action(/^media_done:(\d+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;states.delete(ctx.from.id);return ctx.reply('✅ Soal berhasil disimpan.',questionMenu());});

bot.action('admin_edit_media',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx,'🖼️🎧 *EDIT MEDIA SOAL*\n\nPilih Quiz 1–20.',{parse_mode:'Markdown',...quizManageKeyboard('medialistquiz')});});
bot.action(/^medialistquiz:(\d{1,2})$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const quizNo=Number(ctx.match[1]);const rows=db.questions.filter(q=>Number(q.quiz)===quizNo).slice(-30).reverse();if(!rows.length)return ctx.reply(`📭 Quiz ${quizNo} belum memiliki soal.`);await editScreen(ctx,`🖼️🎧 *MEDIA — QUIZ ${quizNo}*\n\nPilih soal:`,{parse_mode:'Markdown',...Markup.inlineKeyboard(rows.map(q=>[Markup.button.callback(`#${q.id} ${q.photo?'🖼️':''}${q.audio?'🎧':''} ${String(q.question).slice(0,28)}`,`mediamenu:${q.id}`)]).concat([[Markup.button.callback('🔙 KEMBALI','admin_questions')]]))});});
bot.action(/^mediamenu:(\d+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const id=Number(ctx.match[1]),q=db.questions.find(x=>x.id===id);if(!q)return ctx.reply('❌ Soal tidak ditemukan.');await editScreen(ctx,`🖼️🎧 *MEDIA SOAL #${id}*\n\nFoto: *${q.photo?'Ada':'Tidak ada'}*\nAudio: *${q.audio?'Ada':'Tidak ada'}*`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🖼️ GANTI/TAMBAH FOTO','replace_photo:'+id)],[Markup.button.callback('🎧 GANTI/TAMBAH AUDIO','replace_audio:'+id)],[Markup.button.callback('🗑️ HAPUS FOTO','remove_photo:'+id),Markup.button.callback('🗑️ HAPUS AUDIO','remove_audio:'+id)],[Markup.button.callback('🔙 KEMBALI','admin_questions')]])});});
bot.action(/^replace_photo:(\d+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;states.set(ctx.from.id,{type:'replace_photo',id:Number(ctx.match[1])});await ctx.reply('🖼️ Kirim foto baru untuk soal tersebut.');});
bot.action(/^replace_audio:(\d+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;states.set(ctx.from.id,{type:'replace_audio',id:Number(ctx.match[1])});await ctx.reply('🎧 Kirim audio/Voice baru untuk soal tersebut.');});
bot.action(/^remove_photo:(\d+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const q=db.questions.find(x=>x.id===Number(ctx.match[1]));if(q){q.photo=null;saveDB();}return ctx.reply('✅ Foto soal dihapus.',questionMenu());});
bot.action(/^remove_audio:(\d+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const q=db.questions.find(x=>x.id===Number(ctx.match[1]));if(q){q.audio=null;saveDB();}return ctx.reply('✅ Audio soal dihapus.',questionMenu());});

bot.action('admin_edit',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx,'✏️ *EDIT SOAL*\n\nPilih soal dari Quiz nomor berapa?',{parse_mode:'Markdown',...quizManageKeyboard('editquiz')});});
bot.action(/^editquiz:(\d{1,2})$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const quizNo=Number(ctx.match[1]);states.set(ctx.from.id,{type:'edit_question',quizNo});await ctx.reply(`✏️ Kirim ID soal yang ingin diedit dari *Quiz ${quizNo}*.`,{parse_mode:'Markdown'});});
bot.action('admin_list',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx,'📋 *SEMUA SOAL*\n\nPilih Quiz yang ingin dilihat.',{parse_mode:'Markdown',...quizManageKeyboard('listquiz')});});
bot.action(/^listquiz:(\d{1,2})$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const quizNo=Number(ctx.match[1]);const rows=db.questions.filter(q=>Number(q.quiz)===quizNo).slice().reverse().slice(0,50);await editScreen(ctx,rows.length?`📋 *SOAL QUIZ ${quizNo}*\n\n`+rows.map(q=>`#${q.id} [${q.type}] — ${q.question.slice(0,60)}`).join('\n'):`📭 Quiz ${quizNo} belum memiliki soal.`,{parse_mode:'Markdown',...questionMenu()});});
bot.action('admin_delete',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx,'🗑️ *HAPUS SOAL*\n\nPilih soal dari Quiz nomor berapa yang ingin dihapus?',{parse_mode:'Markdown',...quizManageKeyboard('delquiz')});});
bot.action(/^delquiz:(\d{1,2})$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const quizNo=Number(ctx.match[1]);states.set(ctx.from.id,{type:'delete_questions',quizNo});await ctx.reply(`🗑️ *HAPUS SOAL QUIZ ${quizNo}*\n\nKirim ID soal dengan mudah:\n• \`1,2,5,9\`\n• \`10-30\`\n• \`1 4 8\`\n• \`semua\` untuk semua soal Quiz ${quizNo}\n\nSetelah itu bot akan minta konfirmasi *YA*.`,{parse_mode:'Markdown'});});
function timerLabel(cfg){return cfg.timerMode==='none'?'Tanpa batas':cfg.timerMode==='per_question'?`Per soal (${formatSeconds(cfg.time)})`:`Per quiz (${formatSeconds(cfg.time)})`;}
function allTestKeys(){return ['quiz_1','quiz_2','quiz_3','quiz_4','quiz_5','quiz_6','quiz_7','quiz_8','quiz_9','quiz_10','quiz_11','quiz_12','quiz_13','quiz_14','quiz_15','quiz_16','quiz_17','quiz_18','quiz_19','quiz_20','kanji_N5','kanji_N4','kanji_N3','kanji_N2','kanji_N1','kanji_additional','kana_hiragana','kana_katakana','verbs','nouns','na','i','vocab'];}
function testKeyLabel(k){if(k.startsWith('quiz_'))return 'Quiz '+k.split('_')[1];return ({kanji_N5:'Kanji N5',kanji_N4:'Kanji N4',kanji_N3:'Kanji N3',kanji_N2:'Kanji N2',kanji_N1:'Kanji N1',kanji_additional:'Kanji Lainnya',kana_hiragana:'Hiragana',kana_katakana:'Katakana',verbs:'Kata Kerja',nouns:'Kata Benda',na:'Kata Sifat な',i:'Kata Sifat い',vocab:'Kosakata'})[k]||k;}
function countSettingKeyboard(key,backKey='quiz_count'){const cfg=testSetting(key);return Markup.inlineKeyboard([[Markup.button.callback('5','setcount:'+key+':5'),Markup.button.callback('10','setcount:'+key+':10'),Markup.button.callback('15','setcount:'+key+':15')],[Markup.button.callback('20','setcount:'+key+':20'),Markup.button.callback('30','setcount:'+key+':30'),Markup.button.callback('Custom','setcount_custom:'+key)],[Markup.button.callback('🔙 KEMBALI',backKey)]]);}
bot.action('kanji_admin',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const a=db.kanjiAdditional||[];await editScreen(ctx,`🈶 *KELOLA KANJI LAINNYA*\n\nTotal: *${a.length} kanji*\n\nKanji N1–N5 tetap aman. Menu ini khusus untuk data tambahan yang kamu masukkan sendiri.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('➕ TAMBAH KANJI','kanji_admin_add')],[Markup.button.callback('✏️ EDIT KANJI','kanji_admin_edit')],[Markup.button.callback('📋 LIHAT KANJI','kanji_additional')],[Markup.button.callback('🗑️ HAPUS KANJI','kanji_admin_delete')],[Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]])});});
bot.action('kanji_admin_add',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;states.set(ctx.from.id,{type:'kanji_add'});await ctx.reply('➕ Kirim data dengan format:\n\n<b>Kanji | Bacaan | Arti</b>\n\nContoh: <code>春 | はる | musim semi</code>',{parse_mode:'HTML'});});
bot.action('kanji_admin_edit',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;states.set(ctx.from.id,{type:'kanji_edit'});await ctx.reply('✏️ Kirim nomor Kanji Lainnya yang ingin diedit.');});
bot.action('kanji_admin_delete',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;states.set(ctx.from.id,{type:'kanji_delete'});await ctx.reply('🗑️ Kirim nomor Kanji Lainnya yang ingin dihapus. Contoh: 1 atau 1,3,5');});

bot.action('quiz_settings',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx,`⚙️ *PENGATURAN QUIZ*

Mode hasil: *${modeLabel()}*

Setiap Quiz 1–20 memiliki jumlah soal dan pengaturan waktu sendiri.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🔢 JUMLAH SOAL','quiz_count')],[Markup.button.callback('⏱️ WAKTU','timer_settings')],[Markup.button.callback('⚡ LANGSUNG','setmode:immediate')],[Markup.button.callback('📝 SELESAIKAN DULU','setmode:finish')],[Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]])});});
bot.action('quiz_count',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const rows=[];for(let i=1;i<=20;i+=2){rows.push([Markup.button.callback(`Quiz ${i} (${questionsPerQuiz(i)})`,`countpick:${i}`),Markup.button.callback(`Quiz ${i+1} (${questionsPerQuiz(i+1)})`,`countpick:${i+1}`)]);}rows.push([Markup.button.callback('🔙 PENGATURAN QUIZ','quiz_settings')]);await editScreen(ctx,`🔢 *JUMLAH SOAL*

Atur jumlah soal secara terpisah untuk setiap Quiz 1–20 dan setiap test materi.`,{parse_mode:'Markdown',...Markup.inlineKeyboard(rows)});});
bot.action(/^countpick:(\d{1,2})$/,async ctx=>{await ctx.answerCbQuery();const n=Number(ctx.match[1]);if(n<1||n>20||!isAdmin(ctx.from.id))return;await editScreen(ctx,`🔢 *JUMLAH SOAL — QUIZ ${n}*

Saat ini: *${questionsPerQuiz(n)} soal*.

Pilih jumlah baru:`,{parse_mode:'Markdown',...countSettingKeyboard('quiz_'+n,'quiz_count')});});
bot.action(/^setcount:(quiz_\d{1,2}|kanji_N5|kanji_N4|kanji_N3|kanji_N2|kanji_N1|kanji_additional|kana_hiragana|kana_katakana|verbs|nouns|na|i|vocab):(\d+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const key=ctx.match[1],n=Number(ctx.match[2]);if(n<1||n>100)return;db.settings.testSettings[key].count=n;saveDB();await editScreen(ctx,`✅ *JUMLAH SOAL DIPERBARUI*

${testKeyLabel(key)}: *${n} soal*.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🔢 ATUR LAGI',key.startsWith('quiz_')?'countpick:'+key.split('_')[1]:'quiz_count')],[Markup.button.callback('🔙 JUMLAH SOAL','quiz_count')]])});});
bot.action(/^setcount_custom:(.+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const key=ctx.match[1];if(!allTestKeys().includes(key))return;states.set(ctx.from.id,{type:'set_count_custom',key});await ctx.reply(`✏️ Jumlah custom untuk *${testKeyLabel(key)}*

Ketik angka 1–100.`,{parse_mode:'Markdown'});});
bot.action('material_count',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const keys=allTestKeys().filter(k=>!k.startsWith('quiz_'));const rows=[];for(let i=0;i<keys.length;i+=2){const row=[Markup.button.callback(`${testKeyLabel(keys[i])} (${testSetting(keys[i]).count})`,`matcount:${keys[i]}`)];if(keys[i+1])row.push(Markup.button.callback(`${testKeyLabel(keys[i+1])} (${testSetting(keys[i+1]).count})`,`matcount:${keys[i+1]}`));rows.push(row);}rows.push([Markup.button.callback('🔙 JUMLAH SOAL','quiz_count')]);await editScreen(ctx,`📚 *JUMLAH SOAL TEST MATERI*

Setiap kategori memiliki jumlah soal sendiri.`,{parse_mode:'Markdown',...Markup.inlineKeyboard(rows)});});
bot.action(/^matcount:(.+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const key=ctx.match[1];if(!allTestKeys().includes(key)||key.startsWith('quiz_'))return;await editScreen(ctx,`🔢 *JUMLAH SOAL — ${testKeyLabel(key).toUpperCase()}*

Saat ini: *${testSetting(key).count} soal*.`,{parse_mode:'Markdown',...countSettingKeyboard(key,'material_count')});});

bot.action('timer_settings',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const rows=[];for(let i=1;i<=20;i+=2)rows.push([Markup.button.callback(`Quiz ${i}`,`timerpick:quiz_${i}`),Markup.button.callback(`Quiz ${i+1}`,`timerpick:quiz_${i+1}`)]);rows.push([Markup.button.callback('🔙 PENGATURAN QUIZ','quiz_settings')]);await editScreen(ctx,`⏱️ *WAKTU TEST*

Pilih Quiz atau test materi yang ingin diatur.`,{parse_mode:'Markdown',...Markup.inlineKeyboard(rows)});});
bot.action('material_timer',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const keys=allTestKeys().filter(k=>!k.startsWith('quiz_'));const rows=[];for(let i=0;i<keys.length;i+=2){const row=[Markup.button.callback(testKeyLabel(keys[i]),`timerpick:${keys[i]}`)];if(keys[i+1])row.push(Markup.button.callback(testKeyLabel(keys[i+1]),`timerpick:${keys[i+1]}`));rows.push(row);}rows.push([Markup.button.callback('🔙 WAKTU TEST','timer_settings')]);await editScreen(ctx,'⏱️ *WAKTU TEST MATERI*', {parse_mode:'Markdown',...Markup.inlineKeyboard(rows)});});
bot.action(/^timerpick:(.+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const key=ctx.match[1];if(!allTestKeys().includes(key))return;const cfg=testSetting(key);await editScreen(ctx,`⏱️ *WAKTU — ${testKeyLabel(key).toUpperCase()}*

Saat ini: *${timerLabel(cfg)}*.

Pilih mode:`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('⚪ TANPA BATAS','settimer:'+key+':none')],[Markup.button.callback('⏱️ PER SOAL','settimer:'+key+':per_question')],[Markup.button.callback('🕐 PER QUIZ','settimer:'+key+':per_quiz')],[Markup.button.callback('✏️ ATUR DURASI','settime:'+key)],[Markup.button.callback('🔙 KEMBALI',key.startsWith('quiz_')?'timer_settings':'material_timer')]])});});
bot.action(/^settimer:(.+):(none|per_question|per_quiz)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const key=ctx.match[1],mode=ctx.match[2];if(!allTestKeys().includes(key))return;db.settings.testSettings[key].timerMode=mode;if(mode==='none')db.settings.testSettings[key].time=0;saveDB();await editScreen(ctx,`✅ Mode waktu ${testKeyLabel(key)}: *${mode==='none'?'Tanpa batas':mode==='per_question'?'Per soal':'Per quiz'}*.

Atur durasi dengan tombol di bawah.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('⏱️ ATUR DURASI','settime:'+key)],[Markup.button.callback('🔙 KEMBALI',key.startsWith('quiz_')?'timerpick:'+key:'quiz_settings')]])});});
bot.action(/^settime:(.+)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const key=ctx.match[1];if(!allTestKeys().includes(key))return;states.set(ctx.from.id,{type:'set_timer_time',key});await ctx.reply(`⏱️ Atur durasi untuk *${testKeyLabel(key)}*.

Ketik jumlah detik (1–3600).
Contoh: *30* = 30 detik, *600* = 10 menit.`,{parse_mode:'Markdown'});});

bot.action(/^setmode:(immediate|finish)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;db.settings.quizMode=ctx.match[1];saveDB();await editScreen(ctx, `✅ Mode quiz diubah menjadi *${modeLabel()}*.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('⚙️ KEMBALI KE PENGATURAN','quiz_settings')],[Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]])});});
async function broadcastPreview(ctx,payload){
 states.set(ctx.from.id,{type:'broadcast_confirm',payload});
 const kb=Markup.inlineKeyboard([[Markup.button.callback('✅ KIRIM','broadcast_confirm')],[Markup.button.callback('❌ BATAL','broadcast_cancel')]]);
 if(payload.type==='text')return ctx.reply(`📢 PREVIEW BROADCAST\n\n${payload.text}`,kb);
 if(payload.type==='photo')return ctx.replyWithPhoto(payload.file_id,{caption:`📢 PREVIEW BROADCAST\n\n${payload.caption||''}`,...kb});
 return ctx.replyWithAudio(payload.file_id,{caption:`📢 PREVIEW BROADCAST\n\n${payload.caption||''}`,...kb});
}

async function doBroadcast(ctx,payload){
 if(!isAdmin(ctx.from.id))return;
 const users=db.users||[];let ok=0,fail=0;
 for(const u of users){try{if(payload.type==='text')await bot.telegram.sendMessage(u.user_id,payload.text);else if(payload.type==='photo')await bot.telegram.sendPhoto(u.user_id,payload.file_id,{caption:payload.caption||undefined});else if(payload.type==='audio')await bot.telegram.sendAudio(u.user_id,payload.file_id,{caption:payload.caption||undefined});ok++;}catch{fail++;}await new Promise(r=>setTimeout(r,40));}
 return ctx.reply(`📢 *BROADCAST SELESAI*\n\nTerkirim: *${ok}*\nGagal: *${fail}*\nTotal: *${users.length}*`,{parse_mode:'Markdown',...adminMenu()});
}
bot.action('broadcast',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx,'📢 *BROADCAST*\n\nPilih jenis pesan yang ingin dikirim ke semua user.',{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('📝 TEKS','broadcast_start:text')],[Markup.button.callback('🖼️ FOTO','broadcast_start:photo')],[Markup.button.callback('🎧 AUDIO','broadcast_start:audio')],[Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]])});});
bot.action(/^broadcast_start:(text|photo|audio)$/,async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const type=ctx.match[1];states.set(ctx.from.id,{type:type==='text'?'broadcast_text':type==='photo'?'broadcast_photo':'broadcast_audio'});await ctx.reply(type==='text'?'📝 Kirim teks broadcast.':type==='photo'?'🖼️ Kirim foto broadcast.':'🎧 Kirim audio broadcast.');});
bot.action('broadcast_confirm',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const st=states.get(ctx.from.id);if(!st||st.type!=='broadcast_confirm')return;states.delete(ctx.from.id);return doBroadcast(ctx,st.payload);});
bot.action('broadcast_cancel',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;states.delete(ctx.from.id);return editScreen(ctx,'📢 Broadcast dibatalkan.',{parse_mode:'Markdown',...adminMenu()});});
bot.action('admin_reset',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx,`🗑️ *RESET DATA / STATISTIK*

Pilih data yang ingin dihapus.

📊 *RESET STATISTIK*
Menghapus skor, jumlah quiz, benar/salah, poin, dan riwayat kesalahan semua user.

💥 *RESET DATA USER*
Menghapus seluruh data user + statistik + riwayat. Soal, Kanji, Kosakata, pengaturan quiz, dan daftar admin *tetap aman*.

⚠️ Semua reset membutuhkan konfirmasi.`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('📊 RESET STATISTIK','reset_stats_confirm')],[Markup.button.callback('💥 RESET DATA USER','reset_users_confirm')],[Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]])});});

bot.action('reset_stats_confirm',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx,`⚠️ *KONFIRMASI RESET STATISTIK*

Ini akan menghapus statistik dan riwayat jawaban *SEMUA USER*.

Soal, Kanji, Kosakata, admin, dan pengaturan tetap aman.

Yakin?`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('✅ YA, RESET STATISTIK','reset_stats_do'),Markup.button.callback('❌ BATAL','admin_reset')]])});});

bot.action('reset_stats_do',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;db.users.forEach(u=>{u.games=0;u.total_questions=0;u.correct=0;u.points=0;u.activity=[];delete u.lastActivityAt;});db.answerHistory=[];sessions.clear();states.clear();saveDB();await editScreen(ctx,'✅ *STATISTIK BERHASIL DIRESET!*\n\nSemua skor, jumlah quiz, poin, dan riwayat kesalahan user sudah dikosongkan. Data soal, Kanji, Kosakata, admin, dan pengaturan tetap aman.',{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('📊 LIHAT STATISTIK','admin_stats')],[Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]])});});

bot.action('reset_users_confirm',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;await editScreen(ctx,`⚠️ *KONFIRMASI RESET DATA USER*

Ini akan menghapus *SEMUA DATA USER* dan seluruh statistik/riwayat.\n\nTetap aman: soal, Kanji, Kosakata, pengaturan quiz, dan daftar admin.\n\nYakin?`,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('💥 YA, RESET DATA USER','reset_users_do'),Markup.button.callback('❌ BATAL','admin_reset')]])});});

bot.action('reset_users_do',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;db.users=[];db.answerHistory=[];sessions.clear();states.clear();saveDB();await editScreen(ctx,'💥 *DATA USER BERHASIL DIRESET!*\n\nSemua user, skor, statistik, dan riwayat jawaban telah dihapus.\n\nSoal, Kanji, Kosakata, admin, dan pengaturan tetap aman.',{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('📈 STATISTIK','admin_stats')],[Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]])});});

bot.action('admin_stats',async ctx=>{
 await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;
 const h=db.answerHistory||[],total=h.length,correct=h.filter(x=>x.correct).length;
 const users=[...db.users].sort((a,b)=>{const aa=(a.activity||[]).length,bb=(b.activity||[]).length;return bb-aa||((b.points||0)-(a.points||0));});
 const started=users.filter(u=>(u.activity||[]).length>0).length,worked=users.filter(u=>h.some(x=>x.user_id===u.user_id)).length;
 let text=`📈 *STATISTIK DETAIL BOT*\n\n👥 Total user: *${users.length}*\n🚀 Sudah start: *${started}*\n📝 Sudah mengerjakan: *${worked}*\n🕐 Start, belum mengerjakan: *${Math.max(0,users.length-worked)}*\n\n📊 *RINGKASAN JAWABAN*\n\n📝 Total jawaban: *${total}*\n✅ Benar: *${correct}*\n❌ Salah: *${total-correct}*\n🎯 Akurasi: *${total?Math.round(correct/total*100):0}%*\n⭐ Total poin: *${users.reduce((n,u)=>n+(u.points||0),0)}*\n📚 Total soal: *${db.questions.length}*\n\n👥 *DAFTAR PENGGUNA*\n\n💡 🟢 sudah mengerjakan • 🟡 baru start`;
 if(users.length) text+='\n\n'+users.slice(0,20).map((u,i)=>{const did=(u.activity||[]).length>0||h.some(x=>x.user_id===u.user_id);const uh=h.filter(x=>x.user_id===u.user_id),uc=uh.filter(x=>x.correct).length;return `${i+1}. ${did?'🟢':'🟡'} *${u.name||'Tanpa Nama'}*${u.username?' (@'+u.username+')':''}\n🆔 ${u.user_id}\n📝 ${uh.length} jawaban • 🎯 ${uh.length?Math.round(uc/uh.length*100):0}% • ⭐ ${u.points||0}`}).join('\n\n');
 else text+='\n\nBelum ada pengguna.';
 const buttons=users.slice(0,20).map(u=>[Markup.button.callback(`👤 ${u.name||'Tanpa Nama'}${(u.activity||[]).length||h.some(x=>x.user_id===u.user_id)?' 🟢':' 🟡'}`,'stats_user:'+u.user_id)]);
 buttons.push([Markup.button.callback('🔄 SEGARKAN','admin_stats'),Markup.button.callback('🔙 ADMIN PANEL','admin_panel')]);
 await editScreen(ctx,text,{parse_mode:'Markdown',...Markup.inlineKeyboard(buttons)});
});

bot.action(/^stats_user:(\d+)$/,async ctx=>{
 await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;
 const id=Number(ctx.match[1]),u=db.users.find(x=>x.user_id===id);if(!u)return ctx.reply('❌ User tidak ditemukan.');
 const h=(db.answerHistory||[]).filter(x=>x.user_id===id),wrong=h.filter(x=>!x.correct),right=h.filter(x=>x.correct),did=(u.activity||[]).length>0||h.length>0;
 const activity=(u.activity||[]).slice().sort((a,b)=>(b.lastStartedAt||'').localeCompare(a.lastStartedAt||''));
 let text=`👤 *DETAIL USER*\n\n${did?'🟢':'🟡'} *${u.name||'Tanpa Nama'}*${u.username?' (@'+u.username+')':''}\n🆔 ID: ${u.user_id}\n📌 Status: *${did?'Sudah mengerjakan':'Sudah start, belum mengerjakan'}*\n\n📊 *RINGKASAN*\n\n📝 Total jawaban: *${h.length}*\n✅ Benar: *${right.length}*\n❌ Salah: *${wrong.length}*\n🎯 Akurasi: *${h.length?Math.round(right.length/h.length*100):0}%*\n⭐ Total poin: *${u.points||0}*\n\n📚 *SOAL / MATERI DIKERJAKAN*\n`;
 if(activity.length) text+=activity.map(a=>`• ${a.label} — *${h.filter(x=>x.materialKey===a.key).length} soal*`).join('\n'); else text+='Belum ada materi yang dikerjakan.';
 const rows=[[Markup.button.callback('📝 PILIH QUIZ UTAMA','stats_quiz_menu:'+id)],[Markup.button.callback('📚 PILIH TEST MATERI','stats_mat_menu:'+id)],[Markup.button.callback('❌ LIHAT KESALAHAN','stats_wrong:'+id)],[Markup.button.callback('🔙 STATISTIK','admin_stats')]];
 await editScreen(ctx,text,{parse_mode:'Markdown',...Markup.inlineKeyboard(rows)});
});

bot.action(/^stats_quiz_menu:(\d+)$/,async ctx=>{
 await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const id=Number(ctx.match[1]);const u=db.users.find(x=>x.user_id===id);if(!u)return;
 const rows=[];for(let i=1;i<=20;i+=2){const a=(u.activity||[]).find(x=>x.key==='quiz_'+i),b=(u.activity||[]).find(x=>x.key==='quiz_'+(i+1));rows.push([Markup.button.callback(`📝 Quiz ${i}${a?' ✓':''}`,`stats_cat:${id}:quiz_${i}`),Markup.button.callback(`📝 Quiz ${i+1}${b?' ✓':''}`,`stats_cat:${id}:quiz_${i+1}`)]);}rows.push([Markup.button.callback('🔙 DETAIL USER','stats_user:'+id)]);await editScreen(ctx,`📝 *QUIZ UTAMA*\n\nPilih Quiz untuk melihat statistik user secara khusus.\n\n✓ = pernah dimulai`,{parse_mode:'Markdown',...Markup.inlineKeyboard(rows)});
});

bot.action(/^stats_mat_menu:(\d+)$/,async ctx=>{
 await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const id=Number(ctx.match[1]);const u=db.users.find(x=>x.user_id===id);if(!u)return;
 const keys=['kana_hiragana','kana_katakana','kanji_N5','kanji_N4','kanji_N3','kanji_N2','kanji_N1','kanji_additional','verbs','nouns','na','i','vocab'];const rows=[];for(let i=0;i<keys.length;i+=2){const k=keys[i],k2=keys[i+1],a=(u.activity||[]).find(x=>x.key===k),b=k2&&(u.activity||[]).find(x=>x.key===k2);const r=[Markup.button.callback(`${testKeyLabel(k)}${a?' ✓':''}`,`stats_cat:${id}:${k}`)];if(k2)r.push(Markup.button.callback(`${testKeyLabel(k2)}${b?' ✓':''}`,`stats_cat:${id}:${k2}`));rows.push(r);}rows.push([Markup.button.callback('🔙 DETAIL USER','stats_user:'+id)]);await editScreen(ctx,`📚 *TEST MATERI*\n\nPilih materi untuk melihat statistik user.\n\n✓ = pernah dimulai`,{parse_mode:'Markdown',...Markup.inlineKeyboard(rows)});
});

bot.action(/^stats_cat:(\d+):(quiz_\d{1,2}|kanji_N5|kanji_N4|kanji_N3|kanji_N2|kanji_N1|kanji_additional|kana_hiragana|kana_katakana|verbs|nouns|na|i|vocab)$/,async ctx=>{
 await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const id=Number(ctx.match[1]),key=ctx.match[2],u=db.users.find(x=>x.user_id===id);if(!u)return;
 const h=(db.answerHistory||[]).filter(x=>x.user_id===id&&x.materialKey===key),right=h.filter(x=>x.correct),wrong=h.filter(x=>!x.correct),a=(u.activity||[]).find(x=>x.key===key),label=testKeyLabel(key);
 let text=`📊 *STATISTIK — ${label.toUpperCase()}*\n\n👤 ${u.name||'Tanpa Nama'}${u.username?' (@'+u.username+')':''}\n${a?'🟢 Sudah dikerjakan':'🟡 Belum dikerjakan'}\n\n📝 Soal dijawab: *${h.length}*\n✅ Benar: *${right.length}*\n❌ Salah: *${wrong.length}*\n🎯 Akurasi: *${h.length?Math.round(right.length/h.length*100):0}%*\n⭐ Poin: *${key.startsWith('quiz_')?right.length*10:right.length}*`;
 if(a)text+=`\n\n🚀 Mulai: *${a.starts||1} kali*\n📅 Terakhir: *${new Date(a.lastStartedAt).toLocaleString('id-ID',{timeZone:'Asia/Jakarta'})}*`;
 text+='\n\n❌ *KESALAHAN*\n';text+=wrong.length?wrong.slice(-10).reverse().map((x,i)=>`${i+1}. ${x.question||'-'}\n   ❌ ${x.user_answer||'-'}\n   ✅ ${x.correct_answer||'-'}`).join('\n\n'):'Tidak ada kesalahan.';
 const backKey=key.startsWith('quiz_')?'stats_quiz_menu:'+id:'stats_mat_menu:'+id;await editScreen(ctx,text,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🔙 PILIH LAGI',backKey)],[Markup.button.callback('👤 DETAIL USER','stats_user:'+id)],[Markup.button.callback('📈 STATISTIK','admin_stats')]])});
});

bot.action(/^stats_wrong:(\d+)$/,async ctx=>{
 await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;const id=Number(ctx.match[1]),u=db.users.find(x=>x.user_id===id);if(!u)return;const wrong=(db.answerHistory||[]).filter(x=>x.user_id===id&&!x.correct).slice(-20).reverse();let text=`❌ *KESALAHAN TERAKHIR*\n\n👤 ${u.name||'Tanpa Nama'}\n\n`;text+=wrong.length?wrong.map((x,i)=>`${i+1}. *${x.materialLabel||'Quiz'}*\n${x.question||'-'}\n❌ ${x.user_answer||'-'}\n✅ ${x.correct_answer||'-'}`).join('\n\n'):'Belum ada kesalahan.';await editScreen(ctx,text,{parse_mode:'Markdown',...Markup.inlineKeyboard([[Markup.button.callback('🔙 DETAIL USER','stats_user:'+id)],[Markup.button.callback('📈 STATISTIK','admin_stats')]])});
});

bot.action('admin_add_admin',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;states.set(ctx.from.id,{type:'add_admin'});await ctx.reply('➕ Kirim Telegram ID user yang ingin dijadikan admin.');});
bot.action('admin_remove_admin',async ctx=>{await ctx.answerCbQuery();if(!isAdmin(ctx.from.id))return;states.set(ctx.from.id,{type:'remove_admin'});await ctx.reply('🗑️ Kirim Telegram ID admin yang ingin dihapus dari daftar tambahan.');});

// OWNER-ONLY ZIP BACKUP, excludes node_modules/.git/.cache and zip files.
function crc32(buf){let c=~0;for(let i=0;i<buf.length;i++){c^=buf[i];for(let k=0;k<8;k++)c=(c>>>1)^((c&1)?0xEDB88320:0);}return (~c)>>>0;}
function zipStore(entries){
 const locals=[],centrals=[];let offset=0;const now=new Date();
 const dosTime=((now.getHours()&31)<<11)|((now.getMinutes()&63)<<5)|Math.floor(now.getSeconds()/2);
 const dosDate=(((now.getFullYear()-1980)&127)<<9)|(((now.getMonth()+1)&15)<<5)|(now.getDate()&31);
 for(const e of entries){const name=Buffer.from(e.name.replace(/\\/g,'/'),'utf8');const data=Buffer.isBuffer(e.data)?e.data:Buffer.from(e.data);const crc=crc32(data)>>>0;const compressed=zlib.deflateRawSync(data,{level:6});const flags=0x0800,method=8;const h=Buffer.alloc(30);h.writeUInt32LE(0x04034b50,0);h.writeUInt16LE(20,4);h.writeUInt16LE(flags,6);h.writeUInt16LE(method,8);h.writeUInt16LE(dosTime,10);h.writeUInt16LE(dosDate,12);h.writeUInt32LE(crc,14);h.writeUInt32LE(compressed.length,18);h.writeUInt32LE(data.length,22);h.writeUInt16LE(name.length,26);h.writeUInt16LE(0,28);locals.push(h,name,compressed);const c=Buffer.alloc(46);c.writeUInt32LE(0x02014b50,0);c.writeUInt16LE(20,4);c.writeUInt16LE(20,6);c.writeUInt16LE(flags,8);c.writeUInt16LE(method,10);c.writeUInt16LE(dosTime,12);c.writeUInt16LE(dosDate,14);c.writeUInt32LE(crc,16);c.writeUInt32LE(compressed.length,20);c.writeUInt32LE(data.length,24);c.writeUInt16LE(name.length,28);c.writeUInt16LE(0,30);c.writeUInt16LE(0,32);c.writeUInt16LE(0,34);c.writeUInt16LE(0,36);c.writeUInt16LE(0,38);c.writeUInt32LE(0x81B40000,38);c.writeUInt32LE(offset,42);centrals.push(c,name);offset+=h.length+name.length+compressed.length;}
 const body=Buffer.concat(locals),central=Buffer.concat(centrals),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(0,4);end.writeUInt16LE(0,6);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(central.length,12);end.writeUInt32LE(body.length,16);end.writeUInt16LE(0,20);return Buffer.concat([body,central,end]);
}
function collectFiles(dir,root=dir){const out=[];for(const item of fs.readdirSync(dir,{withFileTypes:true})){if(['node_modules','.git','.cache'].includes(item.name)||item.name.endsWith('.zip'))continue;const full=path.join(dir,item.name);if(item.isDirectory())out.push(...collectFiles(full,root));else out.push({name:path.relative(root,full),data:fs.readFileSync(full)});}return out;}
async function sendBackup(chatId,reason='auto'){
  let file='';
  try{
    if(!chatId) throw new Error('OWNER_ID belum diatur.');
    const stamp=new Date().toISOString().replace(/[:.]/g,'-');
    file=path.join(os.tmpdir(),`nihon-quiz-backup-${stamp}.zip`);
    const entries=collectFiles(__dirname);
    if(!entries.length) throw new Error('Tidak ada file yang bisa dibackup.');

    fs.writeFileSync(file,zipStore(entries));
    const size=Math.round(fs.statSync(file).size/1024);

    // Plain text sengaja dipakai agar karakter seperti _, *, [, ] dll.
    // di nama file/daftar pengecualian tidak dianggap Markdown oleh Telegram.
    const caption=[
      '🗄️ NIHON QUIZ BACKUP',
      '',
      `📦 ${reason==='auto'?'Otomatis':'Manual'}`,
      `📁 ${entries.length} file • ${size} KB`,
      '🚫 node_modules, .git, .cache dan ZIP tidak disertakan.'
    ].join('\n');

    await bot.telegram.sendDocument(chatId,Input.fromLocalFile(file),{caption});
    console.log(`Backup ${reason} berhasil: ${file}`);
    return true;
  }catch(e){
    console.error(`Backup ${reason} gagal:`,e);
    if(reason==='manual'){
      try{
        await bot.telegram.sendMessage(chatId,`❌ BACKUP GAGAL\n\n${String(e.message||e).slice(0,800)}`);
      }catch(_){ }
    }
    return false;
  }finally{
    if(file) try{if(fs.existsSync(file))fs.unlinkSync(file);}catch(_){ }
  }
}
setInterval(()=>sendBackup(Number(OWNER_ID),'auto'),Math.max(1,AUTO_BACKUP_HOURS)*60*60*1000);

bot.catch(e=>console.error('Bot error:',e));
(async()=>{try{await fetchKanjiLevels()}catch(e){console.warn('Kanji preload:',e.message)}bot.launch().then(()=>console.log('🇯🇵 Nihon Quiz Bot v4 running...'))})();
process.once('SIGINT',()=>bot.stop('SIGINT'));process.once('SIGTERM',()=>bot.stop('SIGTERM'));
